rm(list=ls()) # clear working environment
install.packages(pkg = "phase", dependencies = T) # install phase and its dependencies
install.packages(pkg = "writexl", dependencies = T) # install writexl and its dependencies

