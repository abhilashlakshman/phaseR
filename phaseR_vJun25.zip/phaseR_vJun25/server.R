library(shiny)
library(shinythemes)
library(shinydashboard)
library(plotly)
library(shinycssloaders)
library(shinyFiles)
library(phase)
library(plotly)
library(zoo)
library(WaveletComp)
library(boot)
library(writexl)

shinyServer(function(input, output, session) {
  
  dataInput <- reactive({
    df <- read.delim(input$file$datapath,
                     header = F)
    date.time <- input$dat.tim
    date.time.split <- strsplit(date.time, split = "; ")
    date <- date.time.split[[1]][1]
    time <- date.time.split[[1]][2]
    td <- trimData(data = df, start.date = date, start.time = time, n.days = input$cyc, bin = input$in.bin, t.cycle = input$t.cycle)
    
  })
  
  binnedDataInput <- reactive({
    for.def.sleep.input <- strsplit(input$def.sleep, split = "-")
    pre.def.sleep.input <- unlist(lapply(for.def.sleep.input, FUN = as.numeric))
    
    if (length(pre.def.sleep.input) == 1) {
      def.sleep.input = c(pre.def.sleep.input[1])
    } else if (length(pre.def.sleep.input) == 2) {
      def.sleep.input = c(pre.def.sleep.input[1], pre.def.sleep.input[2])
    }
    
    if (input$analysis == "Activity") {
      binnedDat <- binData(data = dataInput(), input.bin = input$in.bin, output.bin = input$out.bin, t.cycle = input$t.cycle)
    } else if (input$analysis == "Sleep") {
      binnedDat <- sleepData(data = dataInput(), sleep.def = def.sleep.input, bin = input$out.bin, t.cycle = input$t.cycle)
    } else if (input$analysis == "Wakefulness") {
      binnedDat <- wakeData(data = dataInput(), sleep.def = def.sleep.input, bin = input$out.bin, t.cycle = input$t.cycle)
    } 
  })
  
  output$preview.dat <- renderTable({
    if(!input$preview.dat.button) return(NULL)
    dat <- as.matrix(dataInput()[,-c(1,4:10)])
    colnames(dat)[3:34] <- 1:32
    
    head(dat, 10)
  })
  
  output$preview.binned.dat <- renderTable({
    if(!input$preview.dat.button) return(NULL)
    binnedDataInput()
  })
  
  output$full.mon.dat <- renderPlotly({
    
    if (input$analysis == "Activity") {
      allActograms(data = binnedDataInput(), bin = input$out.bin, t.cycle = input$t.cycle, color = rgb(as.numeric(unlist(strsplit(input$act.color,",")))[1], as.numeric(unlist(strsplit(input$act.color,",")))[2], as.numeric(unlist(strsplit(input$act.color,",")))[3], as.numeric(unlist(strsplit(input$act.color,",")))[4]))
    } else if (input$analysis == "Sleep") {
      for.def.sleep.input <- strsplit(input$def.sleep, split = "-")
      pre.def.sleep.input <- unlist(lapply(for.def.sleep.input, FUN = as.numeric))
      
      if (length(pre.def.sleep.input) == 1) {
        def.sleep.input = c(pre.def.sleep.input[1])
      } else if (length(pre.def.sleep.input) == 2) {
        def.sleep.input = c(pre.def.sleep.input[1], pre.def.sleep.input[2])
      }
      
      allSomnograms(data = dataInput(), sleep.def = def.sleep.input, bin = input$out.bin, t.cycle = input$t.cycle, color = rgb(as.numeric(unlist(strsplit(input$act.color,",")))[1], as.numeric(unlist(strsplit(input$act.color,",")))[2], as.numeric(unlist(strsplit(input$act.color,",")))[3], as.numeric(unlist(strsplit(input$act.color,",")))[4]))
    } else if (input$analysis == "Wakefulness") {
      allActogramsWake(data = dataInput(), sleep.def = input$def.sleep, bin = input$out.bin, t.cycle = input$t.cycle)
    } else {
      allActograms(data = as.matrix(binnedDataInput()), bin = 60, t.cycle = input$t.cycle)
    }
    
  })
  
  periodogram.data <- reactive({
    if(!input$period.dat.table.figure) return(NULL)
    
    if (input$analysis == "Activity") {
      
      if ("ChiSquare" %in% input$per.method) {
        per <- allPeriodogramsAct(data = dataInput(), bin = input$in.bin,
                                  method = "ChiSquare", low.per = input$low.per,
                                  high.per = input$high.per, alpha = input$alpha.per,
                                  time.res = input$res.per
        )
      } else if ("Autocorrelation" %in% input$per.method) {
        per <- allPeriodogramsAct(data = binnedDataInput(), bin = input$out.bin,
                                  method = "Autocorrelation", low.per = input$low.per,
                                  high.per = input$high.per, alpha = input$alpha.per,
                                  time.res = input$res.per
        )
      } else if ("LombScargle" %in% input$per.method) {
        per <- allPeriodogramsAct(data = binnedDataInput(), bin = input$out.bin,
                                  method = "LombScargle", low.per = input$low.per,
                                  high.per = input$high.per, alpha = input$alpha.per,
                                  time.res = input$res.per
        )
      }
      
    } else if (input$analysis == "Wakefulness") {
      
      if ("ChiSquare" %in% input$per.method) {
        per <- allPeriodogramsWake(data = binnedDataInput(), bin = input$out.bin,
                                   method = "ChiSquare", low.per = input$low.per,
                                   high.per = input$high.per, alpha = input$alpha.per,
                                   time.res = input$res.per
        )
      } else if ("Autocorrelation" %in% input$per.method) {
        per <- allPeriodogramsWake(data = binnedDataInput(), bin = input$out.bin,
                                   method = "Autocorrelation", low.per = input$low.per,
                                   high.per = input$high.per, alpha = input$alpha.per,
                                   time.res = input$res.per
        )
      } else if ("LombScargle" %in% input$per.method) {
        per <- allPeriodogramsWake(data = binnedDataInput(), bin = input$out.bin,
                                   method = "LombScargle", low.per = input$low.per,
                                   high.per = input$high.per, alpha = input$alpha.per,
                                   time.res = input$res.per
        )
      }
      
    } else if (input$analysis == "Sleep") {
      
      if ("ChiSquare" %in% input$per.method) {
        for.def.sleep.input <- strsplit(input$def.sleep, split = "-")
        pre.def.sleep.input <- unlist(lapply(for.def.sleep.input, FUN = as.numeric))
        
        if (length(pre.def.sleep.input) == 1) {
          def.sleep.input = c(pre.def.sleep.input[1])
        } else if (length(pre.def.sleep.input) == 2) {
          def.sleep.input = c(pre.def.sleep.input[1], pre.def.sleep.input[2])
        }
        binnedDat <- sleepData(data = dataInput(), sleep.def = def.sleep.input, bin = input$in.bin, t.cycle = input$t.cycle)
        per <- allPeriodogramsSleep(data = binnedDat, bin = input$in.bin,
                                    method = "ChiSquare", low.per = input$low.per,
                                    high.per = input$high.per, alpha = input$alpha.per,
                                    time.res = input$res.per
        )
      } else if ("Autocorrelation" %in% input$per.method) {
        per <- allPeriodogramsSleep(data = binnedDataInput(), bin = input$out.bin,
                                    method = "Autocorrelation", low.per = input$low.per,
                                    high.per = input$high.per, alpha = input$alpha.per,
                                    time.res = input$res.per
        )
      } else if ("LombScargle" %in% input$per.method) {
        per <- allPeriodogramsSleep(data = binnedDataInput(), bin = input$out.bin,
                                    method = "LombScargle", low.per = input$low.per,
                                    high.per = input$high.per, alpha = input$alpha.per,
                                    time.res = input$res.per
        )
      }
      
    }
  })
  
  output$all.periodogram.plot <- renderPlotly({
    periodogram.data()$Plots
  })
  
  output$all.periodogram.dat <- renderTable({
    periodogram.data()$Data
  }, rownames = TRUE
  )
  
  output$all.period.power.download <- downloadHandler(
    filename = function() {
      paste("AllPeriodPower_", Sys.time(), ".csv", sep = "")
    },
    content = function(file) {
      write.csv(periodogram.data()$Data, file, row.names = T)
    }
  )
  
  output$ind.actogram <- renderPlotly({
    
    if (input$analysis == "Activity") {
      indActogram(data = binnedDataInput(), bin = input$out.bin, t.cycle = input$t.cycle, ind = input$channel, key = input$channel, color = rgb(as.numeric(unlist(strsplit(input$act.color,",")))[1], as.numeric(unlist(strsplit(input$act.color,",")))[2], as.numeric(unlist(strsplit(input$act.color,",")))[3], as.numeric(unlist(strsplit(input$act.color,",")))[4]))
    } else if (input$analysis == "Sleep") {
      for.def.sleep.input <- strsplit(input$def.sleep, split = "-")
      pre.def.sleep.input <- unlist(lapply(for.def.sleep.input, FUN = as.numeric))
      
      if (length(pre.def.sleep.input) == 1) {
        def.sleep.input = c(pre.def.sleep.input[1])
      } else if (length(pre.def.sleep.input) == 2) {
        def.sleep.input = c(pre.def.sleep.input[1], pre.def.sleep.input[2])
      }
      
      indSomnogram(data = dataInput(), sleep.def = def.sleep.input, bin = input$out.bin, t.cycle = input$t.cycle, ind = input$channel, key = input$channel, color = rgb(as.numeric(unlist(strsplit(input$act.color,",")))[1], as.numeric(unlist(strsplit(input$act.color,",")))[2], as.numeric(unlist(strsplit(input$act.color,",")))[3], as.numeric(unlist(strsplit(input$act.color,",")))[4]))
    } else if (input$analysis == "Wakefulness") {
      indActogramWake(data = dataInput(), sleep.def = input$def.sleep, bin = input$out.bin, t.cycle = input$t.cycle, ind = input$channel, key = input$channel)
    }
    
  })
  
  output$ind.periodogram.cs <- renderPlotly({
    
    if (input$analysis == "Activity") {
      
      per <- indPeriodogramAct(data = dataInput(), bin = input$in.bin,
                               method = "ChiSquare", low.per = input$low.per,
                               high.per = input$high.per, alpha = input$alpha.per,
                               time.res = input$res.per, ind = input$channel
      )
    } else if (input$analysis == "Sleep") {
      for.def.sleep.input <- strsplit(input$def.sleep, split = "-")
      pre.def.sleep.input <- unlist(lapply(for.def.sleep.input, FUN = as.numeric))
      
      if (length(pre.def.sleep.input) == 1) {
        def.sleep.input = c(pre.def.sleep.input[1])
      } else if (length(pre.def.sleep.input) == 2) {
        def.sleep.input = c(pre.def.sleep.input[1], pre.def.sleep.input[2])
      }
      binnedDat <- sleepData(data = dataInput(), sleep.def = def.sleep.input, bin = input$in.bin, t.cycle = input$t.cycle)
      per <- indPeriodogramSleep(data = binnedDat, bin = input$in.bin,
                                 method = "ChiSquare", low.per = input$low.per,
                                 high.per = input$high.per, alpha = input$alpha.per,
                                 time.res = input$res.per, ind = input$channel
      )
    }
  })
  
  output$ind.periodogram.ls <- renderPlotly({
    
    if (input$analysis == "Activity") {
      
      per <- indPeriodogramAct(data = binnedDataInput(), bin = input$out.bin,
                               method = "LombScargle", low.per = input$low.per,
                               high.per = input$high.per, alpha = input$alpha.per,
                               time.res = input$res.per, ind = input$channel
      )
    } else if (input$analysis == "Sleep") {
      per <- indPeriodogramSleep(data = binnedDataInput(), bin = input$out.bin,
                                 method = "LombScargle", low.per = input$low.per,
                                 high.per = input$high.per, alpha = input$alpha.per,
                                 time.res = input$res.per, ind = input$channel
      )
    }
  })
  
  output$ind.periodogram.auto <- renderPlotly({
    
    if (input$analysis == "Activity") {
      
      per <- indPeriodogramAct(data = binnedDataInput(), bin = input$out.bin,
                               method = "Autocorrelation", low.per = input$low.per,
                               high.per = input$high.per, alpha = input$alpha.per,
                               time.res = input$res.per, ind = input$channel
      )
    } else if (input$analysis == "Sleep") {
      
      per <- indPeriodogramSleep(data = binnedDataInput(), bin = input$out.bin,
                                 method = "Autocorrelation", low.per = input$low.per,
                                 high.per = input$high.per, alpha = input$alpha.per,
                                 time.res = input$res.per, ind = input$channel
      )
    }
  })
  
  
  phase.dataTable <- reactive({
    phase.dataTable <- matrix(NA, nrow = input$cyc, ncol = 32)
  })
  phase <- matrix()
  
  output$dataTable.phase <- renderTable({
    d <- event_data("plotly_click", source = "actogram.phases")
    phase <<- matrix(c(phase,
                       (binnedDataInput()[d$x,1]), d$curveNumber, as.numeric(d$key)),
                     nrow = 3)
    
  })
  
  phase.restructured <- reactive({
    for.phase.restr <- phase[,-1]
    new.phase = t(for.phase.restr)
    colnames(new.phase) <- c("Phase (ZT/CT/Time)", "Cycle", "Channel")
    col.order <- c("Channel", "Cycle", "Phase (ZT/CT/Time)")
    new.phase[,col.order]
  })
  
  output$phase.download <- downloadHandler(
    filename = function() {
      paste("Phase_fromActograms_", Sys.time(), ".csv", sep = "")
    },
    content = function(file) {
      write.csv(phase.restructured(), file, row.names = F)
    }
  )
  
  
  #####################################################################################################################
  #####################################################################################################################
  #####################################################################################################################
  #####################################################################################################################
  #####################################################################################################################
  #####################################################################################################################
  cwt.dat.ls <- reactive({
    if(!input$compute.scalogram) return(NULL)
    
    if (input$rm.chan.cwt == "None") {
      final.rm.chan = c()
    } else {
      for.rm.channels = strsplit(input$rm.chan.cwt, split = c(","))
      for.rm.channels2 = unlist(lapply(for.rm.channels, FUN = strsplit, split = ":"), recursive = F)
      for.rm.channels3 = lapply(for.rm.channels2, as.numeric)
      rm.chan.vec = rep(NA, 32)
      
      for (i in 1:length(for.rm.channels3)) {
        x = for.rm.channels3[[i]]
        if (length(x) == 1) {
          rm.chan.vec[x] = x
        } else if (length(x) == 2) {
          y = seq(x[1], x[2], by = 1)
          rm.chan.vec[y[1]:y[length(y)]] = y
        }
      }
      
      final.rm.chan = as.numeric(na.omit(rm.chan.vec))
    }
    
    dat.scal <- binnedDataInput()[,-1]
    
    dat.scal[,final.rm.chan] <- 0
    
    s.per.hr <- 60/input$out.bin
    
    cwt.rds <- list()
    
    for (i in 1:length(dat.scal[1,])) {
      if (sum(dat.scal[,i]) == (input$out.bin * length(dat.scal[,i])) || sum(dat.scal[,i]) == 0) {
        cwt.rds[[i]] <- NA
      } else {
        cwt.rds[[i]] <- WaveletComp::analyze.wavelet(my.data = dat.scal, my.series = paste("I", i, sep = ""),
                                                     loess.span = 0, dt = 1, lowerPeriod = input$low.per.cwt * s.per.hr,
                                                     upperPeriod = input$high.per.cwt * s.per.hr, dj = 1/100,
                                                     make.pval = F, verbose = F)
      }
    }
    
    names(cwt.rds) <- paste("Ch-", 1:32, sep = "")
    cwt.no.na <- cwt.rds[which(!is.na(cwt.rds))]
    
    power.mat <- list()
    power.norm <- list()
    final.power.norm <- list()
    
    if (input$edge.rm.cwt == FALSE) {
      for (i in 1:length(cwt.no.na)) {
        pow <- cwt.no.na[[i]]$Power
        power.mat[[i]] <- pow
      }
    } else if (input$edge.rm.cwt == TRUE) {
      for (i in 1:length(cwt.no.na)) {
        pow <- cwt.no.na[[i]]$Power
        for (j in 1:length(pow[,1])) {
          idx2rem <- round((cwt.no.na[[i]]$Period[j]) * 1.5)
          pow[j,1:idx2rem] <- NA
          pow[j,(((length(pow[1,]) - idx2rem) + 1):length(pow[1,]))] <- NA
        }
        power.mat[[i]] <- pow
      }
    }
    
    for (i in 1:length(cwt.no.na)) {
      avg.power <- mean(as.vector(power.mat[[i]]), na.rm = TRUE)
      power.norm[[i]] <- power.mat[[i]]/avg.power
      
      x <- as.data.frame(power.mat[[i]]/avg.power)
      colnames(x) <- seq(input$out.bin/60, input$t.cycle * input$cyc, by = input$out.bin/60)
      
      y <- as.data.frame(cbind(cwt.no.na[[1]]$Period/s.per.hr, x))
      colnames(y)[1] <- "Period"
      final.power.norm[[i]] <- y
      
    }
    names(final.power.norm) <- names(cwt.no.na)
    
    power.array <- do.call(cbind, power.norm)
    power.array <- array(power.array, dim = c(dim(power.norm[[i]]), length(power.norm)))
    power.mean <- apply(power.array, c(1,2), mean, na.rm = TRUE)
    rownames(power.mean) <- cwt.no.na[[1]]$Period
    power.mean
    
    #############################################################################################
    #############################################################################################
    #############################################################################################
    time.avg.power <- as.data.frame(matrix(NA, nrow = length(cwt.no.na[[1]]$Period), ncol = 33)) # create an empty data frame to store time averaged power for each fly
    colnames(time.avg.power) <- c("period", names(cwt.no.na)) # name column headers
    time.avg.power$period <- cwt.no.na[[1]]$Period/s.per.hr # fill period values
    
    for (i in 1:length(cwt.no.na)) { # calculate time averaged power for fly-i
      ind.pow <- power.norm[[i]] # store power matrix for fy-i in a separate variable
      time.avg.power[,i+1] <- rowMeans(ind.pow, na.rm = T) # carry out average across time for fly-i
    }
    
    time.avg.power[,final.rm.chan+1] <- NA
    
    time.avg.power$mean <- rowMeans(time.avg.power[,2:33], na.rm = T) # compute mean power across flies for each period
    
    if (input$boot.cwt.logical == TRUE) {
      # bootstrap upper and lower 95% confidence intervals
      for (i in 1:length(time.avg.power[,1])) { # use loop to bootstrap 95%CI for period-i
        tryCatch({
          mean.fx <- function(x, index) { # define function to calculate mean
            d <- x[index]
            return(mean(d, na.rm = T))
          }
          boot.x <- boot::boot(data = as.numeric(time.avg.power[i,2:33]), statistic = mean.fx, R = input$boot.rep) # bootstrap for period-i
          bci <- boot::boot.ci(boot.out = boot.x, conf = 0.95, type = "bca") # estimate CI
          time.avg.power[i,"lower.ci95"] <- bci$bca[4] # assign lower bound
          time.avg.power[i,"upper.ci95"] <- bci$bca[5] # assign upper bound
        }, error = function(e){})
      }
      
      time.avg.power
    } else if (input$boot.cwt.logical == FALSE) {
      time.avg.power
    }
    #############################################################################################
    #############################################################################################
    #############################################################################################
    
    list(
      "mean.power.mat" = power.mean,
      "norm.power.list" = final.power.norm,
      "avg.power" = time.avg.power
    )
    
  })
  #####################################################################################################################
  #####################################################################################################################
  #####################################################################################################################
  #####################################################################################################################
  #####################################################################################################################
  #####################################################################################################################
  #####################################################################################################################
  
  output$mean.scalogram <- renderPlotly({
    if(!input$compute.scalogram) return(NULL)
    
    df <- cwt.dat.ls()$mean.power.mat
    s.per.hr <- 60/input$out.bin
    f1 <- list( # define font details
      family = "Arial, sans-serif",
      size = 16,
      color = "black"
    )
    f2 <- list( # define font details
      family = "Arial, sans-serif",
      size = 12,
      color = "black"
    )
    
    p <- plotly::plot_ly(
      # plot scalograms
    )%>%
      add_trace(
        x = 1:dim(df)[2],
        y = rownames(df),
        z = df,
        type = "heatmap",
        colors = colorRamp(c("blue", "cyan", "green", "yellow", "red")),
        zauto = F,
        zmin = 0,
        zmax = input$z.max.cwt,
        showscale = T
      )%>%
      layout(
        showlegend = F,
        yaxis = list(
          type = "log",
          showgrid = F,
          showline = T,
          titlefont = f1,
          tickfont = f2,
          title = "Period (h)",
          linecolor = "black",
          autotick = FALSE,
          ticks = "outside",
          tick0 = 0,
          dtick = 1 * s.per.hr,
          ticklen = 7,
          tickcolor = "black",
          range = c(log10((input$low.per.cwt) * s.per.hr), log10((input$high.per.cwt) * s.per.hr)),
          ticktext = as.list(
            c(1,2,4,8,12,17,24,35)
          ),
          tickvals = as.list(
            c(1,2,4,8,12,17,24,35) * s.per.hr
          ),
          tickmode = "array"
        ),
        xaxis = list(
          showgrid = F,
          showline = T,
          titlefont = f1,
          tickfont = f2,
          title = "Days",
          linecolor = "black",
          autotick = FALSE,
          ticks = "outside",
          tick0 = 0,
          dtick = (s.per.hr * input$t.cycle)/2,
          ticklen = 7,
          tickcolor = "black",
          range = c(0, dim(df)[2]),
          ticktext = as.list(
            seq(0.5, input$cyc, by = 0.5)
          ),
          tickvals = as.list(
            seq((s.per.hr * input$t.cycle)/2, s.per.hr * input$t.cycle * input$cyc, (s.per.hr * input$t.cycle)/2)
          ),
          tickmode = "array"
        )
      )
      
      p
      
  })
  

  output$cwt.period.power <- renderPlot({
    dat <- as.data.frame(cwt.dat.ls()$avg.power)
    
    if (input$boot.cwt.logical == TRUE) {
      plot(dat[,'period'], dat[,'mean'], type = "l", col = "black", xlim = c(input$low.per.cwt,input$high.per.cwt), ylim = c(0,input$y.max.cwt),
           log = "x", xlab = "Period (h)", ylab = "Normalized power", main = "Period vs time-averaged power")
      polygon(x = c(dat[,'period'], rev(dat[,'period'])),
              y = c(dat[,'lower.ci95'], rev(dat[,'mean'])),
              border = NA, col = rgb(0,0,0,0.3)) # add lower CI
      polygon(x = c(dat[,'period'], rev(dat[,'period'])),
              y = c(dat[,'upper.ci95'], rev(dat[,'mean'])),
              border = NA, col = rgb(0,0,0,0.3)) # add upper CI
    } else if (input$boot.cwt.logical == FALSE) {
      plot(dat[,'period'], dat[,'mean'], type = "l", col = "black", xlim = c(input$low.per.cwt,input$high.per.cwt), ylim = c(0,input$y.max.cwt),
           log = "x", xlab = "Period (h)", ylab = "Normalized power", main = "Period vs time-averaged power")
    }
    
    
  })
  
  output$cwt.period.power.dat <- renderTable({
    cwt.dat.ls()$avg.power
  })
  
  output$cwt.period.power.download <- downloadHandler(
    filename = function() {
      paste("CWT_PeriodPower_", Sys.time(), ".csv", sep = "")
    },
    content = function(file) {
      dat <- cwt.dat.ls()$avg.power
      write.csv(dat, file, row.names = F)
    }
  )
  

  output$scalogram.dat.download <- downloadHandler(
    filename = function() {
      paste("CWT_ScalogramData_", Sys.time(), ".xlsx", sep = "")
    },
    content = function(file) {
      dat <- cwt.dat.ls()$norm.power.list
      writexl::write_xlsx(dat, file, col_names = T)
    }
  )
  
  output$ind.scalogram <- renderPlotly({
    
    pre.dat <- cwt.dat.ls()$norm.power.list
    for.plot.title <- names(pre.dat)
    
    s.per.hr <- 60/input$out.bin
    
    dat <- pre.dat[[input$channel.cwt]][,-1]
    period <- pre.dat[[input$channel.cwt]][,"Period"] * s.per.hr
    
    f1 <- list( # define font details
      family = "Arial, sans-serif",
      size = 16,
      color = "black"
    )
    f2 <- list( # define font details
      family = "Arial, sans-serif",
      size = 12,
      color = "black"
    )
    
    p <- plotly::plot_ly(
      # plot scalograms
    )%>%
      add_trace(
        x = 1:length(dat[1,]),
        y = period,
        z = as.matrix(dat),
        type = "heatmap",
        colors = colorRamp(c("blue", "cyan", "green", "yellow", "red")),
        zauto = F,
        zmin = 0,
        zmax = input$z.max.cwt,
        showscale = T
      )%>%
      layout(
        title = for.plot.title[input$channel.cwt],
        showlegend = F,
        yaxis = list(
          type = "log",
          showgrid = F,
          showline = T,
          titlefont = f1,
          tickfont = f2,
          title = "Period (h)",
          linecolor = "black",
          autotick = FALSE,
          ticks = "outside",
          tick0 = 0,
          dtick = 1 * s.per.hr,
          ticklen = 7,
          tickcolor = "black",
          range = c(log10((input$low.per.cwt) * s.per.hr), log10((input$high.per.cwt) * s.per.hr)),
          ticktext = as.list(
            c(1,2,4,8,12,17,24,35)
          ),
          tickvals = as.list(
            c(1,2,4,8,12,17,24,35) * s.per.hr
          ),
          tickmode = "array"
        ),
        xaxis = list(
          showgrid = F,
          showline = T,
          titlefont = f1,
          tickfont = f2,
          title = "Days",
          linecolor = "black",
          autotick = FALSE,
          ticks = "outside",
          tick0 = 0,
          dtick = (s.per.hr * input$t.cycle)/2,
          ticklen = 7,
          tickcolor = "black",
          range = c(0, length(dat[1,])),
          ticktext = as.list(
            seq(0.5, input$cyc, by = 0.5)
          ),
          tickvals = as.list(
            seq((s.per.hr * input$t.cycle)/2, s.per.hr * input$t.cycle * input$cyc, (s.per.hr * input$t.cycle)/2)
          ),
          tickmode = "array"
        )
      )
    
    p
    
  })
  
  
  ll.period.dat <- reactive({
    df <- cwt.dat.ls()$avg.power
    for.names <- names(cwt.dat.ls()$norm.power.list)
    df.sub <- subset(df, period > input$low.per.ultradian & period < input$high.per.ultradian)
    
    ll.period <- c()
    
    for (k in 2:33) {
      if (is.na(df.sub[1,k])) {
        ll.period[k-1] <- NA
      } else {
        max.ind <- which.max(df.sub[,k])
        ll.period[k-1] <- df.sub$period[max.ind]
      }
    }
    
    
    ll.period.out <- data.frame(
      "Channel" = for.names,
      "Period" = na.omit(ll.period)
    )
    
    ll.period.out
    
  })
  
  output$cwt.ultradian.period.dat <- renderTable({
    ll.period.dat()
  })
  
  output$cwt.ultradian.period.download <- downloadHandler(
    filename = function() {
      paste("UltradianPeriodsExtracted_", Sys.time(), ".csv", sep = "")
    },
    content = function(file) {
      write.csv(ll.period.dat(), file, row.names = F)
    }
  )

  
  output$profile.plot <- renderPlotly({
    if (input$avg.type == "None") {
      plotly_empty(type = "scatter", mode = "markers") %>%
        config(
          displayModeBar = FALSE
        ) %>%
        layout(
          title = list(
            text = "No plot is generated for average over = None",
            yref = "paper",
            y = 0.5
          )
        )
    } else {
      if (input$rm.chan.prof == "None") {
        final.rm.chan = c()
      } else {
        for.rm.channels = strsplit(input$rm.chan.prof, split = c(","))
        for.rm.channels2 = unlist(lapply(for.rm.channels, FUN = strsplit, split = ":"), recursive = F)
        for.rm.channels3 = lapply(for.rm.channels2, as.numeric)
        rm.chan.vec = rep(NA, 32)
        
        for (i in 1:length(for.rm.channels3)) {
          x = for.rm.channels3[[i]]
          if (length(x) == 1) {
            rm.chan.vec[x] = x
          } else if (length(x) == 2) {
            y = seq(x[1], x[2], by = 1)
            rm.chan.vec[y[1]:y[length(y)]] = y
          }
        }
        
        final.rm.chan = as.numeric(na.omit(rm.chan.vec))
      }
      
      if (input$analysis == "Activity") {
        pro <- profilesAct(data = binnedDataInput(), bin = input$out.bin, t.cycle = input$t.cycle, average.type = input$avg.type, rm.channels = final.rm.chan)
        pro$Plot
      } else if (input$analysis == "Sleep") {
        pro <- profilesSleep(data = binnedDataInput(), bin = input$out.bin, t.cycle = input$t.cycle, average.type = input$avg.type, rm.channels = final.rm.chan)
        pro$Plot
      } else if (input$analysis == "Wake") {
        pro <- profilesWake(data = binnedDataInput(), bin = input$out.bin, t.cycle = input$t.cycle, average.type = input$avg.type, rm.channels = final.rm.chan)
        pro$Plot
      }
    }
  })
  
  profileData <- reactive({
    if (input$rm.chan.prof == "None") {
      final.rm.chan = c()
    } else {
      for.rm.channels = strsplit(input$rm.chan.prof, split = c(","))
      for.rm.channels2 = unlist(lapply(for.rm.channels, FUN = strsplit, split = ":"), recursive = F)
      for.rm.channels3 = lapply(for.rm.channels2, as.numeric)
      rm.chan.vec = rep(NA, 32)
      
      for (i in 1:length(for.rm.channels3)) {
        x = for.rm.channels3[[i]]
        if (length(x) == 1) {
          rm.chan.vec[x] = x
        } else if (length(x) == 2) {
          y = seq(x[1], x[2], by = 1)
          rm.chan.vec[y[1]:y[length(y)]] = y
        }
      }
      
      final.rm.chan = as.numeric(na.omit(rm.chan.vec))
    }
    
    if (input$analysis == "Activity") {
      pro <- profilesAct(data = binnedDataInput(), bin = input$out.bin, t.cycle = input$t.cycle, average.type = input$avg.type, rm.channels = final.rm.chan)
    } else if (input$analysis == "Sleep") {
      pro <- profilesSleep(data = binnedDataInput(), bin = input$out.bin, t.cycle = input$t.cycle, average.type = input$avg.type, rm.channels = final.rm.chan)
    } else if (input$analysis == "Wake") {
      pro <- profilesWake(data = binnedDataInput(), bin = input$out.bin, t.cycle = input$t.cycle, average.type = input$avg.type, rm.channels = final.rm.chan)
    }
  })
  
  output$profile.dat <- renderTable({
    if (input$avg.type == "None") {
      profileData()
    } else {
      profileData()$Profiles
    }
  })
  
  output$profile.download <- downloadHandler(
    filename = function() {
      paste("Profiles_", Sys.time(), ".csv", sep = "")
    },
    content = function(file) {
      if (input$avg.type == "None") {
        write.csv(profileData(), file, row.names = F)
      } else {
        write.csv(profileData()$Profiles, file, row.names = F)
      }
    }
  )
  
  slp.bout.dist.data <- reactive({
    slp.dat <- sleepData(data = dataInput(), sleep.def = c(5), bin = 1, t.cycle = input$t.cycle)[,-1]
    
    slp.bout.dist.lengths <- c()
    
    bout.dist.out.list <- list()
    
    for (i in 1:length(slp.dat[1,])) {
      
      x <- slp.dat[,i]
      y <- rle(x)
      d_y <- as.data.frame(unclass(y))
      d_y$end <- cumsum(d_y$lengths)
      d_y$start <- d_y$end - d_y$lengths + 1
      
      dd_y <- subset(d_y, d_y$values == 1)
      
      slp.bout.dist.lengths[i] <- length(dd_y[,1])
      
      bout.dist.out.list[[i]] <- dd_y$lengths
    }
    
    nrow.new.mat <- max(slp.bout.dist.lengths, na.rm = T)
    
    new.mat <- matrix(NA, nrow = nrow.new.mat, ncol = 32)
    colnames(new.mat) <- paste("Ch-", 1:32, sep = "")
    
    for (i in 1:length(bout.dist.out.list)) {
      x <- bout.dist.out.list[[i]]
      new.mat[1:length(x),i] <- x
    }
    
    new.mat
    
  })
  
  output$bout.dist <- renderPlotly({
    
    bout.dat <- slp.bout.dist.data()
    
    f1 <- list(
      family = "Arial, sans-serif",
      size = 20,
      color = "black"
    )
    f2 <- list(
      family = "Arial, sans-serif",
      size = 14,
      color = "black"
    )
    
    
    if (input$analysis == "Sleep") {
      plot_ly(
        x = ~na.omit(bout.dat[,input$ch.viz]),
        type = "histogram",
        marker = list(
          color = rgb(0.7,0,0,0.5) 
        ),
        nbinsx = 50
      )%>%
        # add_segments(
        #   x = 5, xend = 5, y = 0, yend = 100
        # )%>%
        # add_segments(
        #   x = 30, xend = 30, y = 0, yend = 100
        # )%>%
        # add_segments(
        #   x = 60, xend = 60, y = 0, yend = 100
        # )%>%
        layout(
          showlegend = F,
          xaxis = list(
            showgrid = T,
            showline = T,
            titlefont = f1,
            tickfont = f2,
            title = "Bout length (mins)",
            linecolor = "black",
            mirror = TRUE,
            autotick = TRUE,
            ticks = "inside",
            tickcolor = toRGB("black")
          ),
          yaxis = list(
            showgrid = T,
            showline = T,
            titlefont = f1,
            tickfont = f2,
            title = "Frequency (counts)",
            linecolor = "black",
            mirror = TRUE,
            autotick = TRUE,
            ticks = "inside",
            tickcolor = toRGB("black")
          )
        )
    } else {
      plotly_empty(type = "scatter", mode = "markers") %>%
        config(
          displayModeBar = FALSE
        ) %>%
        layout(
          title = list(
            text = "Plot is generated only for analysis = Sleep",
            yref = "paper",
            y = 0.5
          )
        )
    }
  })
  
  output$bout.dist.dat1 <- renderTable({
    
    if (input$analysis == "Sleep") {
      slp.bout.dist.data()
    } else {
      data.frame(
        "NOTE" = paste("This analysis is available only for Sleep data")
      )
    }
    
  })
  
  
  output$bout.dist.download1 <- downloadHandler(
    filename = function() {
      paste("BoutDistribution_", Sys.time(), ".csv", sep = "")
    },
    content = function(file) {
      new.out <- slp.bout.dist.data()
      # pre.new.out <- cbind(slp.statData(), tot.sleepData())
      # new.out <- pre.new.out[,c(1,2,3,4,5,11,6,7,8,9,12)]
      write.csv(new.out, file, row.names = F)
    }
  )
  
  
  
  slp.statData <- reactive({
    
    if (input$rm.chan.slp.stat == "None") {
      final.rm.chan = c()
    } else {
      for.rm.channels = strsplit(input$rm.chan.slp.stat, split = c(","))
      for.rm.channels2 = unlist(lapply(for.rm.channels, FUN = strsplit, split = ":"), recursive = F)
      for.rm.channels3 = lapply(for.rm.channels2, as.numeric)
      rm.chan.vec = rep(NA, 32)
      
      for (i in 1:length(for.rm.channels3)) {
        x = for.rm.channels3[[i]]
        if (length(x) == 1) {
          rm.chan.vec[x] = x
        } else if (length(x) == 2) {
          y = seq(x[1], x[2], by = 1)
          rm.chan.vec[y[1]:y[length(y)]] = y
        }
      }
      
      final.rm.chan = as.numeric(na.omit(rm.chan.vec))
    }
    
    
    for.def.sleep.input <- strsplit(input$def.sleep, split = "-")
    pre.def.sleep.input <- unlist(lapply(for.def.sleep.input, FUN = as.numeric))
    
    if (length(pre.def.sleep.input) == 1) {
      def.sleep.input = c(pre.def.sleep.input[1])
    } else if (length(pre.def.sleep.input) == 2) {
      def.sleep.input = c(pre.def.sleep.input[1], pre.def.sleep.input[2])
    }
    
    pre.slp.stat <- sleepStat(data = dataInput(), sleep.def = def.sleep.input, t.cycle = input$t.cycle, photoperiod = input$viz.photoperiod)
    pre.slp.stat[final.rm.chan,2:11] <- NA
    
    slp.stat <- pre.slp.stat
    
    # if (is.null(final.rm.chan)) {
    #   slp.stat <- sleepStat(data = dataInput(), sleep.def = def.sleep.input, t.cycle = input$t.cycle, photoperiod = input$viz.photoperiod)
    # } else {
    #   dat <- dataInput()
    #   dat[,(10+final.rm.chan)] <- NA
    #   slp.stat <- sleepStat(data = dat, sleep.def = def.sleep.input, t.cycle = input$t.cycle, photoperiod = input$viz.photoperiod)
    # }
    
  })
  
  output$slp.stat.plot1 <- renderPlotly({
    
    if (input$analysis == "Sleep") {
      slp.stat <- slp.statData()
      
      f1 <- list(
        family = "Arial, sans-serif",
        size = 20,
        color = "black"
      )
      f2 <- list(
        family = "Arial, sans-serif",
        size = 14,
        color = "black"
      )
      
      bout.num <- plot_ly(
        y = na.omit(slp.stat[,"Day.BoutNumber"]),
        type = "box",
        name = "Day",
        marker = list(
          color = rgb(0,0,1,0.5)
        ),
        line = list(
          color = rgb(0,0,1,0.5)
        ),
        fillcolor = rgb(0,0,1,0.5),
        showlegend = F
      )%>%
        add_trace(
          y = na.omit(slp.stat[,"Night.BoutNumber"]),
          marker = list(
            color = rgb(1,0,0,0.5)
          ),
          line = list(
            color = rgb(1,0,0,0.5)
          ),
          fillcolor = rgb(1,0,0,0.5),
          showlegend = F,
          name = "Night"
        )
      
      bout.dur <- plot_ly(
        y = na.omit(slp.stat[,"Day.BoutDuration.Median"]),
        type = "box",
        name = "Day",
        marker = list(
          color = rgb(0,0,1,0.5)
        ),
        line = list(
          color = rgb(0,0,1,0.5)
        ),
        fillcolor = rgb(0,0,1,0.5),
        showlegend = F
      )%>%
        add_trace(
          y = na.omit(slp.stat[,"Night.BoutDuration.Median"]),
          marker = list(
            color = rgb(1,0,0,0.5)
          ),
          line = list(
            color = rgb(1,0,0,0.5)
          ),
          fillcolor = rgb(1,0,0,0.5),
          showlegend = F,
          name = "Night"
        )
      
      bout.lat <- plot_ly(
        y = na.omit(slp.stat[,"Day.Latency"]),
        type = "box",
        name = "Day",
        marker = list(
          color = rgb(0,0,1,0.5)
        ),
        line = list(
          color = rgb(0,0,1,0.5)
        ),
        fillcolor = rgb(0,0,1,0.5),
        showlegend = F
      )%>%
        add_trace(
          y = na.omit(slp.stat[,"Night.Latency"]),
          marker = list(
            color = rgb(1,0,0,0.5)
          ),
          line = list(
            color = rgb(1,0,0,0.5)
          ),
          fillcolor = rgb(1,0,0,0.5),
          showlegend = F,
          name = "Night"
        )
      
      tot.slp <- plot_ly(
        y = na.omit(slp.stat[,"Day.Total"]),
        type = "box",
        name = "Day",
        marker = list(
          color = rgb(0,0,1,0.5)
        ),
        line = list(
          color = rgb(0,0,1,0.5)
        ),
        fillcolor = rgb(0,0,1,0.5),
        showlegend = F
      )%>%
        add_trace(
          y = na.omit(slp.stat[,"Night.Total"]),
          marker = list(
            color = rgb(1,0,0,0.5)
          ),
          line = list(
            color = rgb(1,0,0,0.5)
          ),
          fillcolor = rgb(1,0,0,0.5),
          showlegend = F,
          name = "Night"
        )
      
      subplot(
        bout.num, bout.dur, bout.lat, tot.slp, nrows = 2,
        shareX = F, shareY = F, margin = 0.06
      )%>%
        layout(
          showlegend = F,
          xaxis = list(
            showgrid = F,
            showline = T,
            titlefont = f1,
            tickfont = f2,
            title = "",
            linecolor = "black",
            mirror = TRUE,
            autotick = TRUE,
            ticks = "inside",
            tickcolor = toRGB("black")
          ),
          xaxis2 = list(
            showgrid = F,
            showline = T,
            titlefont = f1,
            tickfont = f2,
            title = "",
            linecolor = "black",
            mirror = TRUE,
            autotick = TRUE,
            ticks = "inside",
            tickcolor = toRGB("black")
          ),
          xaxis3 = list(
            showgrid = F,
            showline = T,
            titlefont = f1,
            tickfont = f2,
            title = "",
            linecolor = "black",
            mirror = TRUE,
            autotick = TRUE,
            ticks = "inside",
            tickcolor = toRGB("black")
          ),
          xaxis4 = list(
            showgrid = F,
            showline = T,
            titlefont = f1,
            tickfont = f2,
            title = "",
            linecolor = "black",
            mirror = TRUE,
            autotick = TRUE,
            ticks = "inside",
            tickcolor = toRGB("black")
          ),
          yaxis = list(
            showgrid = F,
            showline = T,
            titlefont = f1,
            tickfont = f2,
            title = "Bout numbers",
            linecolor = "black",
            mirror = TRUE,
            autotick = TRUE,
            ticks = "inside",
            tickcolor = toRGB("black")
          ),
          yaxis2 = list(
            showgrid = F,
            showline = T,
            titlefont = f1,
            tickfont = f2,
            title = "Bout duration (mins)",
            linecolor = "black",
            mirror = TRUE,
            autotick = TRUE,
            ticks = "inside",
            tickcolor = toRGB("black")
          ),
          yaxis3 = list(
            showgrid = F,
            showline = T,
            titlefont = f1,
            tickfont = f2,
            title = "Bout latency (mins)",
            linecolor = "black",
            mirror = TRUE,
            autotick = TRUE,
            ticks = "inside",
            tickcolor = toRGB("black")
          ),
          yaxis4 = list(
            showgrid = F,
            showline = T,
            titlefont = f1,
            tickfont = f2,
            title = "Total sleep (mins)",
            linecolor = "black",
            mirror = TRUE,
            autotick = TRUE,
            ticks = "inside",
            tickcolor = toRGB("black")
          )
        )
      
    } else {
      plotly_empty(type = "scatter", mode = "markers") %>%
        config(
          displayModeBar = FALSE
        ) %>%
        layout(
          title = list(
            text = "Plot is generated only for analysis = Sleep",
            yref = "paper",
            y = 0.5
          )
        )
    }
    
  })
  
  output$slp.stat.dat1 <- renderTable({
    
    if (input$analysis == "Sleep") {
      slp.statData()
    } else {
      data.frame(
        "NOTE" = paste("This analysis is available only for Sleep data")
      )
    }
    
  })
  
  output$slp.stat.download1 <- downloadHandler(
    filename = function() {
      paste("SleepStats_", Sys.time(), ".csv", sep = "")
    },
    content = function(file) {
      new.out <- slp.statData()
      # pre.new.out <- cbind(slp.statData(), tot.sleepData())
      # new.out <- pre.new.out[,c(1,2,3,4,5,11,6,7,8,9,12)]
      write.csv(new.out, file, row.names = F)
    }
  )
  
  hypnogram.dat <- reactive({
    bd <- binData(data = dataInput(), input.bin = 1, output.bin = 1, t.cycle = input$t.cycle)[,-1]
    bd[bd != 0] <- 1
    sd.short <- sleepData(data = dataInput(), sleep.def = c(5,30), bin = 1, input$t.cycle)[,-1]
    sd.inter <- sleepData(data = dataInput(), sleep.def = c(30,60), bin = 1, input$t.cycle)[,-1]
    sd.long <- sleepData(data = dataInput(), sleep.def = c(60), bin = 1, input$t.cycle)[,-1]
    
    list(
      "activity" = bd,
      "short.sleep" = sd.short,
      "inter.sleep" = sd.inter,
      "long.sleep" = sd.long
    )
  })
  
  output$hypnograms <- renderPlot({
    if (input$analysis == "Sleep") {
      
      bd <- hypnogram.dat()$activity
      sd.short <- hypnogram.dat()$short.sleep
      sd.inter <- hypnogram.dat()$inter.sleep
      sd.long <- hypnogram.dat()$long.sleep
      
      plot(1:(1440*input$cyc), bd[,input$ch.viz]+3, type = "h", ylim = c(0,4), xaxt = "n", yaxt = "n", col = rgb(0,0,0,0), main = paste("Channel-", input$ch.viz, sep = ""),
           xlab = "Time", ylab = "Sleep stages")
      polygon(x = c(min(1:(1440*input$cyc)), 1:(1440*input$cyc), max(1:(1440*input$cyc))),
              y = c(min(bd[,input$ch.viz]+3),
                    bd[,input$ch.viz]+3,
                    min(bd[,input$ch.viz]+3)),
              col = rgb(251/255, 118/255, 89/255, 1), border = NA)
      lines(1:(1440*input$cyc), sd.short[,input$ch.viz]+2, type = "h", col = rgb(0,0,0,0))
      polygon(x = c(min(1:(1440*input$cyc)), 1:(1440*input$cyc), max(1:(1440*input$cyc))),
              y = c(min(sd.short[,input$ch.viz]+2),
                    sd.short[,input$ch.viz]+2,
                    min(sd.short[,input$ch.viz]+2)),
              col = rgb(130/255, 207/255, 251/255, 1), border = NA)
      lines(1:(1440*input$cyc), sd.inter[,input$ch.viz]+1, type = "h", col = rgb(0,0,0,0))
      polygon(x = c(min(1:(1440*input$cyc)), 1:(1440*input$cyc), max(1:(1440*input$cyc))),
              y = c(min(sd.inter[,input$ch.viz]+1),
                    sd.inter[,input$ch.viz]+1,
                    min(sd.inter[,input$ch.viz]+1)),
              col = rgb(59/255, 130/255, 246/255, 1), border = NA)
      lines(1:(1440*input$cyc), sd.long[,input$ch.viz], type = "h", col = rgb(0,0,0,0))
      polygon(x = c(min(1:(1440*input$cyc)), 1:(1440*input$cyc), max(1:(1440*input$cyc))),
              y = c(min(sd.long[,input$ch.viz]),
                    sd.long[,input$ch.viz],
                    min(sd.long[,input$ch.viz])),
              col = rgb(54/255, 53/255, 157/255, 1), border = NA)
    } else {
      plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')
      text(x = 0.5, y = 0.5, "Plot is generated only for analysis = Sleep", cex = 1.5, col = "black")
    }
  })
  
  output$ant.lat.plot <- renderPlotly({
    if (input$rm.chan.ant == "None") {
      final.rm.chan = c()
    } else {
      for.rm.channels = strsplit(input$rm.chan.ant, split = c(","))
      for.rm.channels2 = unlist(lapply(for.rm.channels, FUN = strsplit, split = ":"), recursive = F)
      for.rm.channels3 = lapply(for.rm.channels2, as.numeric)
      rm.chan.vec = rep(NA, 32)
      
      for (i in 1:length(for.rm.channels3)) {
        x = for.rm.channels3[[i]]
        if (length(x) == 1) {
          rm.chan.vec[x] = x
        } else if (length(x) == 2) {
          y = seq(x[1], x[2], by = 1)
          rm.chan.vec[y[1]:y[length(y)]] = y
        }
      }
      
      final.rm.chan = as.numeric(na.omit(rm.chan.vec))
    }
    
    if (input$analysis == "Activity") {
      if (input$ant.method == "Slope") {
        if (input$max.y.ant == "Automatic") {
          ant <- anticipationAct(data = dataInput(), method = input$ant.method, t.cycle = input$t.cycle, morn.win.start = input$morn.win.start, eve.win.start = input$eve.win.start,
                                 eve.win.end = input$eve.win.end, rm.channels = final.rm.chan)
          f1 <- list(
            family = "Arial, sans-serif",
            size = 20,
            color = "black"
          )
          f2 <- list(
            family = "Arial, sans-serif",
            size = 14,
            color = "black"
          )
          subplot(ant$Plot.morn, ant$Plot.eve, nrows = 1, shareY = F, margin = 0.05)%>%
            layout(
              showlegend = T,
              xaxis = list(
                showgrid = F,
                showline = T,
                titlefont = f1,
                tickfont = f2,
                title = "ZT (h)",
                linecolor = "black",
                mirror = TRUE,
                autotick = TRUE,
                ticks = "inside",
                tickcolor = toRGB("black")
              ),
              xaxis2 = list(
                showgrid = F,
                showline = T,
                titlefont = f1,
                tickfont = f2,
                title = "ZT (h)",
                linecolor = "black",
                mirror = TRUE,
                autotick = TRUE,
                ticks = "inside",
                tickcolor = toRGB("black")
              ),
              yaxis = list(
                showgrid = F,
                showline = T,
                titlefont = f1,
                tickfont = f2,
                title = "Morning Activity",
                linecolor = "black",
                mirror = TRUE,
                autotick = TRUE,
                ticks = "inside",
                tickcolor = toRGB("black")
              ),
              yaxis2 = list(
                showgrid = F,
                showline = T,
                titlefont = f1,
                tickfont = f2,
                title = "Evening Activity",
                linecolor = "black",
                mirror = TRUE,
                autotick = TRUE,
                ticks = "inside",
                tickcolor = toRGB("black")
              )
            )
        } else {
          ant <- anticipationAct(data = dataInput(), method = input$ant.method, t.cycle = input$t.cycle, morn.win.start = input$morn.win.start, eve.win.start = input$eve.win.start,
                                 eve.win.end = input$eve.win.end, rm.channels = final.rm.chan, max.y.morn = as.numeric(input$max.y.ant), max.y.eve = as.numeric(input$max.y.ant))
          f1 <- list(
            family = "Arial, sans-serif",
            size = 20,
            color = "black"
          )
          f2 <- list(
            family = "Arial, sans-serif",
            size = 14,
            color = "black"
          )
          subplot(ant$Plot.morn, ant$Plot.eve, nrows = 1, shareY = F, margin = 0.05)%>%
            layout(
              showlegend = T,
              xaxis = list(
                showgrid = F,
                showline = T,
                titlefont = f1,
                tickfont = f2,
                title = "ZT (h)",
                linecolor = "black",
                mirror = TRUE,
                autotick = TRUE,
                ticks = "inside",
                tickcolor = toRGB("black")
              ),
              xaxis2 = list(
                showgrid = F,
                showline = T,
                titlefont = f1,
                tickfont = f2,
                title = "ZT (h)",
                linecolor = "black",
                mirror = TRUE,
                autotick = TRUE,
                ticks = "inside",
                tickcolor = toRGB("black")
              ),
              yaxis = list(
                showgrid = F,
                showline = T,
                titlefont = f1,
                tickfont = f2,
                title = "Morning Activity",
                linecolor = "black",
                mirror = TRUE,
                autotick = TRUE,
                ticks = "inside",
                tickcolor = toRGB("black")
              ),
              yaxis2 = list(
                showgrid = F,
                showline = T,
                titlefont = f1,
                tickfont = f2,
                title = "Evening Activity",
                linecolor = "black",
                mirror = TRUE,
                autotick = TRUE,
                ticks = "inside",
                tickcolor = toRGB("black")
              )
            )
        }
        
      } else {
        plotly_empty(type = "scatter", mode = "markers") %>%
          config(
            displayModeBar = FALSE
          ) %>%
          layout(
            title = list(
              text = "Plot is generated only for method = Slope",
              yref = "paper",
              y = 0.5
            )
          )
      }
      
    } else {
      plotly_empty(type = "scatter", mode = "markers") %>%
        config(
          displayModeBar = FALSE
        ) %>%
        layout(
          title = list(
            text = "Analysis not available for Sleep/Wakefulness data.",
            yref = "paper",
            y = 0.5
          )
        )
    }
  })
  
  antlatData <- reactive({
    if (input$rm.chan.ant == "None") {
      final.rm.chan = c()
    } else {
      for.rm.channels = strsplit(input$rm.chan.ant, split = c(","))
      for.rm.channels2 = unlist(lapply(for.rm.channels, FUN = strsplit, split = ":"), recursive = F)
      for.rm.channels3 = lapply(for.rm.channels2, as.numeric)
      rm.chan.vec = rep(NA, 32)
      
      for (i in 1:length(for.rm.channels3)) {
        x = for.rm.channels3[[i]]
        if (length(x) == 1) {
          rm.chan.vec[x] = x
        } else if (length(x) == 2) {
          y = seq(x[1], x[2], by = 1)
          rm.chan.vec[y[1]:y[length(y)]] = y
        }
      }
      
      final.rm.chan = as.numeric(na.omit(rm.chan.vec))
    }
    
    for.def.sleep.input <- strsplit(input$def.sleep, split = "-")
    pre.def.sleep.input <- unlist(lapply(for.def.sleep.input, FUN = as.numeric))
    
    if (length(pre.def.sleep.input) == 1) {
      def.sleep.input = c(pre.def.sleep.input[1])
    } else if (length(pre.def.sleep.input) == 2) {
      def.sleep.input = c(pre.def.sleep.input[1], pre.def.sleep.input[2])
    }
    
    if (input$analysis == "Activity") {
      if (input$ant.method == "Slope") {
        pre.ant <- anticipationAct(data = dataInput(), method = input$ant.method, t.cycle = input$t.cycle, morn.win.start = input$morn.win.start, eve.win.start = input$eve.win.start,
                                   eve.win.end = input$eve.win.end, rm.channels = final.rm.chan)
        ant = pre.ant$Data
      } else {
        ant <- anticipationAct(data = dataInput(), method = input$ant.method, t.cycle = input$t.cycle, morn.win.start = input$morn.win.start, eve.win.start = input$eve.win.start,
                               eve.win.end = input$eve.win.end, rm.channels = final.rm.chan)
      }
    } else if (input$analysis == "Sleep") {
      data.frame(
        "NOTE" = paste("Anticipation analyses are not available for Sleep/Wakefulness data")
      )
      # slp.stat <- sleepStat(input = dataInput(), sleep.def = def.sleep.input, t.cycle = input$t.cycle, photoperiod = input$photoperiod)
    } else if (input$analysis == "Wakefulness") {
      data.frame(
        "NOTE" = paste("Anticipation analyses are not available for Sleep/Wakefulness data")
      )
    }
  })
  
  output$ant.lat.dat <- renderTable({
    antlatData()
  })
  
  output$ant.lat.download <- downloadHandler(
    filename = function() {
      paste("AnticipationLatency_", Sys.time(), ".csv", sep = "")
    },
    content = function(file) {
      write.csv(antlatData(), file, row.names = F)
    }
  )
  
  #################################################
  pk.id.df <- reactive({
    
    pks <- peakIdentifier(data = dataInput(), filt.order = input$filt.order, filt.length = input$filt.length,
                          min.peak.dist = input$min.peak.dist, peak.ht.scal = input$peak.ht.scal,
                          ZT = c(as.numeric(input$pk.win1), as.numeric(input$pk.win2)),
                          rm.channels = c())
    
  })
  
  output$pk.identifier.plot <- renderPlotly({
    if (!input$for.pk.id) return(NULL)
    
    if (input$analysis == "Activity") {
      
      pk.id.df()$Plots
      
    } else {
      plotly_empty(type = "scatter", mode = "markers") %>%
        config(
          displayModeBar = FALSE
        ) %>%
        layout(
          title = list(
            text = "This analysis is not available for Sleep/Wakefulness data.",
            yref = "paper",
            y = 0.5
          )
        )
    }
    
  })
  
  output$pk.id.dat <- renderTable({
    if(!input$for.pk.id) return(NULL)
    if (input$analysis == "Activity") {
      pk.id.df()$Data
    } else {
      data.frame(
        "NOTE" = paste("This analysis is not available for Sleep/Wakefulness data")
      )
    }
    
  })
  
  output$pk.id.download <- downloadHandler(
    filename = function() {
      paste("IdentifiedPeakPhases_", Sys.time(), ".csv", sep = "")
    },
    content = function(file) {
      write.csv(pk.id.df()$Data, file, row.names = F)
    }
  )
  
  #################################################
  
  output$rose.plot <- renderPlotly({
    if (input$rm.chan.circ == "None") {
      final.rm.chan = c()
    } else {
      for.rm.channels = strsplit(input$rm.chan.circ, split = c(","))
      for.rm.channels2 = unlist(lapply(for.rm.channels, FUN = strsplit, split = ":"), recursive = F)
      for.rm.channels3 = lapply(for.rm.channels2, as.numeric)
      rm.chan.vec = rep(NA, 32)
      
      for (i in 1:length(for.rm.channels3)) {
        x = for.rm.channels3[[i]]
        if (length(x) == 1) {
          rm.chan.vec[x] = x
        } else if (length(x) == 2) {
          y = seq(x[1], x[2], by = 1)
          rm.chan.vec[y[1]:y[length(y)]] = y
        }
      }
      
      final.rm.chan = as.numeric(na.omit(rm.chan.vec))
    }
    
    if (input$analysis == "Activity") {
      rosePlotsAct(data = binnedDataInput(), bin = input$out.bin, t.cycle = input$t.cycle, rm.channels = final.rm.chan)
    } else if (input$analysis == "Sleep") {
      rosePlotsSleep(data = binnedDataInput(), bin = input$out.bin, t.cycle = input$t.cycle, rm.channels = final.rm.chan)
    } else if (input$analysis == "Wakefulness") {
      rosePlotsWake(data = binnedDataInput(), bin = input$out.bin, t.cycle = input$t.cycle, rm.channels = final.rm.chan)
    }
  })
  
  output$com.plot <- renderPlotly({
    if (input$rm.chan.circ == "None") {
      final.rm.chan = c()
    } else {
      for.rm.channels = strsplit(input$rm.chan.circ, split = c(","))
      for.rm.channels2 = unlist(lapply(for.rm.channels, FUN = strsplit, split = ":"), recursive = F)
      for.rm.channels3 = lapply(for.rm.channels2, as.numeric)
      rm.chan.vec = rep(NA, 32)
      
      for (i in 1:length(for.rm.channels3)) {
        x = for.rm.channels3[[i]]
        if (length(x) == 1) {
          rm.chan.vec[x] = x
        } else if (length(x) == 2) {
          y = seq(x[1], x[2], by = 1)
          rm.chan.vec[y[1]:y[length(y)]] = y
        }
      }
      
      final.rm.chan = as.numeric(na.omit(rm.chan.vec))
    }
    
    win.1 = as.numeric(unlist(strsplit(input$win1, split = ",")))
    win.2 = as.numeric(unlist(strsplit(input$win2, split = ",")))
    
    win1.start <- win.1[1]
    win1.end <- win.1[2]
    win2.start <- win.2[1]
    win2.end <- win.2[2]
    
    com.data <- CoM(input = binnedDataInput(), data = input$analysis, bin = input$out.bin, t.cycle = input$t.cycle, window = list(c(win1.start, win1.end), c(win2.start, win2.end)), rm.channels = final.rm.chan)
    com.data$Plot
  })
  
  
  comData <- reactive({
    if (input$rm.chan.circ == "None") {
      final.rm.chan = c()
    } else {
      for.rm.channels = strsplit(input$rm.chan.circ, split = c(","))
      for.rm.channels2 = unlist(lapply(for.rm.channels, FUN = strsplit, split = ":"), recursive = F)
      for.rm.channels3 = lapply(for.rm.channels2, as.numeric)
      rm.chan.vec = rep(NA, 32)
      
      for (i in 1:length(for.rm.channels3)) {
        x = for.rm.channels3[[i]]
        if (length(x) == 1) {
          rm.chan.vec[x] = x
        } else if (length(x) == 2) {
          y = seq(x[1], x[2], by = 1)
          rm.chan.vec[y[1]:y[length(y)]] = y
        }
      }
      
      final.rm.chan = as.numeric(na.omit(rm.chan.vec))
    }
    
    win.1 = as.numeric(unlist(strsplit(input$win1, split = ",")))
    win.2 = as.numeric(unlist(strsplit(input$win2, split = ",")))
    
    win1.start <- win.1[1]
    win1.end <- win.1[2]
    win2.start <- win.2[1]
    win2.end <- win.2[2]
    
    com.data <- CoM(input = binnedDataInput(), data = input$analysis, bin = input$out.bin, t.cycle = input$t.cycle, window = list(c(win1.start, win1.end), c(win2.start, win2.end)), rm.channels = final.rm.chan)
  })
  
  output$com.dat <- renderTable({
    comData()$Data
  })
  
  output$com.download <- downloadHandler(
    filename = function() {
      paste("CenterOfMass_", Sys.time(), ".csv", sep = "")
    },
    content = function(file) {
      write.csv(comData()$Data, file, row.names = F)
    }
  )
  
  output$batch.preview.dat <- renderTable({
    print(input$batch.file)
  })
  
  batchDataIn <- reactive({
    tmp <- list()
    
    for (i in 1:length(input$batch.file[,1])) {
      df <- read.delim(
        input$batch.file[i,'datapath'],
        header = F
      )
      
      date.time <- input$batch.dat.tim
      date.time.split <- strsplit(date.time, split = "; ")
      date <- date.time.split[[1]][1]
      time <- date.time.split[[1]][2]
      tmp[[i]] <- trimData(data = df, start.date = date, start.time = time, n.days = input$batch.cyc, bin = input$batch.in.bin, t.cycle = input$batch.t.cycle)
    }
    
    return(tmp)
  })
  
  batchNames <- reactive({
    tmp <- c()
    
    for (i in 1:length(batchDataIn())) {
      pre.df <- input$batch.file[i,'name']
      df <- as.vector(unlist(strsplit(pre.df, split = ".txt")))
      tmp[i] <- paste(df, sep = "")
    }
    return(tmp)
  })
  
  final.batch.names <- reactive({
    
    if (input$batch.analysis == "Period and power") {
      if (input$batch.perpow.act.slp == "Activity") {
        nam <- print(paste("Compiled_PeriodPower_Activity_", Sys.time(), ".csv", sep = ""))
      } else if (input$batch.perpow.act.slp == "Sleep") {
        nam <- print(paste("Compiled_PeriodPower_Sleep_", Sys.time(), ".csv", sep = ""))
      }
    } else if (input$batch.analysis == "Profiles") {
      if (input$batch.pro.act.slp == "Activity") {
        nam <- print(paste("Compiled_Profiles_Activity_", Sys.time(), ".csv", sep = ""))
      } else if (input$batch.pro.act.slp == "Sleep") {
        nam <- print(paste("Compiled_Profiles_Sleep_", Sys.time(), ".csv", sep = ""))
      }
    } else if (input$batch.analysis == "Anticipation") {
      nam <- print(paste("Compiled_Anticipation_", Sys.time(), ".csv", sep = ""))
    } else if (input$batch.analysis == "Phases of activity peaks") {
      nam <- print(paste("Compiled_Activity_Peaks_", Sys.time(), ".csv", sep = ""))
    } else if (input$batch.analysis == "Sleep statistics") {
      nam <- print(paste("Compiled_Sleep_Statistics_", Sys.time(), ".csv", sep = ""))
    } else if (input$batch.analysis == "Circular statistics") {
      if (input$batch.circstat.act.slp == "Activity") {
        nam <- print(paste("Compiled_CircStats_Activity_", Sys.time(), ".csv", sep = ""))
      } else if (input$batch.circstat.act.slp == "Sleep") {
        nam <- print(paste("Compiled_CircStats_Sleep_", Sys.time(), ".csv", sep = ""))
      }
    }
    
    return(nam)
  })
  
  batch.out.data <- reactive({
    
    tmp.out <- list()
    
    withProgress(message = "Carrying out computations", value = 0, {
      for (i in 1:length(batchDataIn())) {
        
        if (input$batch.analysis == "Period and power") {
          if ("ChiSquare" %in% input$batch.per.method) {
            if (input$batch.perpow.act.slp == "Activity") {
              per <- allPeriodogramsAct(data = batchDataIn()[[i]], bin = input$batch.in.bin,
                                        method = "ChiSquare", low.per = input$batch.low.per,
                                        high.per = input$batch.high.per, alpha = input$batch.alpha.per,
                                        time.res = input$batch.res.per
              )
              tmp.out[[i]] <- per$Data
            } else if (input$batch.perpow.act.slp == "Sleep") {
              batch.for.def.sleep.input <- strsplit(input$batch.def.sleep.perpow, split = "-")
              batch.pre.def.sleep.input <- unlist(lapply(batch.for.def.sleep.input, FUN = as.numeric))
              
              if (length(batch.pre.def.sleep.input) == 1) {
                batch.def.sleep.input = c(batch.pre.def.sleep.input[1])
              } else if (length(batch.pre.def.sleep.input) == 2) {
                batch.def.sleep.input = c(batch.pre.def.sleep.input[1], batch.pre.def.sleep.input[2])
              }
              
              sd <- sleepData(data = batchDataIn()[[i]], sleep.def = batch.def.sleep.input,
                              bin = input$batch.in.bin, t.cycle = input$batch.t.cycle)
              
              per <- allPeriodogramsSleep(data = sd, bin = input$batch.in.bin,
                                          method = "ChiSquare", low.per = input$batch.low.per,
                                          high.per = input$batch.high.per, alpha = input$batch.alpha.per,
                                          time.res = input$batch.res.per
              )
              tmp.out[[i]] <- per$Data
            }
          } else if ("Autocorrelation" %in% input$batch.per.method) {
            if (input$batch.perpow.act.slp == "Activity") {
              dat <- binData(data = batchDataIn()[[i]], input.bin = input$batch.in.bin,
                             output.bin = input$batch.out.bin, t.cycle = input$batch.t.cycle)
              per <- allPeriodogramsAct(data = dat, bin = input$batch.out.bin,
                                        method = "Autocorrelation", low.per = input$batch.low.per,
                                        high.per = input$batch.high.per, alpha = input$batch.alpha.per,
                                        time.res = input$batch.res.per
              )
              tmp.out[[i]] <- per$Data
            } else if (input$batch.perpow.act.slp == "Sleep") {
              batch.for.def.sleep.input <- strsplit(input$batch.def.sleep.perpow, split = "-")
              batch.pre.def.sleep.input <- unlist(lapply(batch.for.def.sleep.input, FUN = as.numeric))
              
              if (length(batch.pre.def.sleep.input) == 1) {
                batch.def.sleep.input = c(batch.pre.def.sleep.input[1])
              } else if (length(batch.pre.def.sleep.input) == 2) {
                batch.def.sleep.input = c(batch.pre.def.sleep.input[1], batch.pre.def.sleep.input[2])
              }
              
              sd <- sleepData(data = batchDataIn()[[i]], sleep.def = batch.def.sleep.input,
                              bin = input$batch.out.bin, t.cycle = input$batch.t.cycle)
              per <- allPeriodogramsSleep(data = sd, bin = input$batch.out.bin,
                                          method = "Autocorrelation", low.per = input$batch.low.per,
                                          high.per = input$batch.high.per, alpha = input$batch.alpha.per,
                                          time.res = input$batch.res.per
              )
              tmp.out[[i]] <- per$Data
              
              
            }
          } else if ("LombScargle" %in% input$batch.per.method) {
            if (input$batch.perpow.act.slp == "Activity") {
              dat <- binData(data = batchDataIn()[[i]], input.bin = input$batch.in.bin,
                             output.bin = input$batch.out.bin, t.cycle = input$batch.t.cycle)
              per <- allPeriodogramsAct(data = dat, bin = input$batch.out.bin,
                                        method = "LombScargle", low.per = input$batch.low.per,
                                        high.per = input$batch.high.per, alpha = input$batch.alpha.per,
                                        time.res = input$batch.res.per
              )
              tmp.out[[i]] <- per$Data
            } else if (input$batch.perpow.act.slp == "Sleep") {
              batch.for.def.sleep.input <- strsplit(input$batch.def.sleep.perpow, split = "-")
              batch.pre.def.sleep.input <- unlist(lapply(batch.for.def.sleep.input, FUN = as.numeric))
              
              if (length(batch.pre.def.sleep.input) == 1) {
                batch.def.sleep.input = c(batch.pre.def.sleep.input[1])
              } else if (length(batch.pre.def.sleep.input) == 2) {
                batch.def.sleep.input = c(batch.pre.def.sleep.input[1], batch.pre.def.sleep.input[2])
              }
              
              sd <- sleepData(data = batchDataIn()[[i]], sleep.def = batch.def.sleep.input,
                              bin = input$batch.out.bin, t.cycle = input$batch.t.cycle)
              per <- allPeriodogramsSleep(data = sd, bin = input$batch.out.bin,
                                          method = "LombScargle", low.per = input$batch.low.per,
                                          high.per = input$batch.high.per, alpha = input$batch.alpha.per,
                                          time.res = input$batch.res.per
              )
              tmp.out[[i]] <- per$Data
            }
          }
        } else if (input$batch.analysis == "Profiles") {
          
          if (input$batch.pro.act.slp == "Activity") {
            batch.bd <- binData(data = batchDataIn()[[i]], input.bin = input$batch.in.bin, output.bin = input$batch.out.bin, t.cycle = input$batch.t.cycle)
            batch.pro <- profilesAct(data = batch.bd, bin = input$batch.out.bin, t.cycle = input$batch.t.cycle, average.type = input$batch.avg.type)
            
            if (is.list(batch.pro)) {
              tmp.out[[i]] <- batch.pro$Profiles
            } else {
              tmp.out[[i]] <- batch.pro
            }
          } else if (input$batch.pro.act.slp == "Sleep") {
            batch.for.def.sleep.input <- strsplit(input$batch.def.sleep.pro, split = "-")
            batch.pre.def.sleep.input <- unlist(lapply(batch.for.def.sleep.input, FUN = as.numeric))
            
            if (length(batch.pre.def.sleep.input) == 1) {
              batch.def.sleep.input = c(batch.pre.def.sleep.input[1])
            } else if (length(batch.pre.def.sleep.input) == 2) {
              batch.def.sleep.input = c(batch.pre.def.sleep.input[1], batch.pre.def.sleep.input[2])
            }
            
            batch.sd <- sleepData(data = batchDataIn()[[i]], sleep.def = batch.def.sleep.input,
                                  bin = input$batch.out.bin, t.cycle = input$batch.t.cycle)
            
            batch.pro <- profilesSleep(data = batch.sd, bin = input$batch.out.bin, t.cycle = input$batch.t.cycle, average.type = input$batch.avg.type)
            
            if (length(batch.pro) == 2) {
              tmp.out[[i]] <- batch.pro$Profiles
            } else {
              tmp.out[[i]] <- batch.pro
            }
          }
          
        } else if (input$batch.analysis == "Anticipation") {
          batch.ant <- anticipationAct(data = batchDataIn()[[i]], method = input$batch.ant.method, t.cycle = input$batch.t.cycle, morn.win.start = input$batch.morn.win.start,
                                       eve.win.start = input$batch.eve.win.start,
                                       eve.win.end = input$batch.eve.win.end)
          
          if (is.list(batch.ant)) {
            tmp.out[[i]] <- batch.ant$Data
          } else {
            tmp.out[[i]] <- batch.ant
          }
          
        } else if (input$batch.analysis == "Phases of activity peaks") {
          
          batch.pks <- peakIdentifier(data = batchDataIn()[[i]], filt.order = input$batch.filt.order, filt.length = input$batch.filt.length,
                                      min.peak.dist = input$batch.min.peak.dist, peak.ht.scal = input$batch.peak.ht.scal,
                                      ZT = c(as.numeric(input$batch.pk.win1), as.numeric(input$batch.pk.win2)))
          
          tmp.out[[i]] <- batch.pks$Data
          
        } else if (input$batch.analysis == "Sleep statistics") {
          
          batch.for.def.sleep.input <- strsplit(input$batch.def.sleep.stat, split = "-")
          batch.pre.def.sleep.input <- unlist(lapply(batch.for.def.sleep.input, FUN = as.numeric))
          
          if (length(batch.pre.def.sleep.input) == 1) {
            batch.def.sleep.input = c(batch.pre.def.sleep.input[1])
          } else if (length(batch.pre.def.sleep.input) == 2) {
            batch.def.sleep.input = c(batch.pre.def.sleep.input[1], batch.pre.def.sleep.input[2])
          }
          
          batch.slp.stat <- sleepStat(data = batchDataIn()[[i]], sleep.def = batch.def.sleep.input,
                                      t.cycle = input$batch.t.cycle, photoperiod = input$batch.photoperiod)
          
          tmp.out[[i]] <- batch.slp.stat
          
        } else if (input$batch.analysis == "Circular statistics") {
          
          if (input$batch.circstat.act.slp == "Activity") {
            batch.win.1 = as.numeric(unlist(strsplit(input$batch.win1, split = ",")))
            batch.win.2 = as.numeric(unlist(strsplit(input$batch.win2, split = ",")))
            
            batch.win1.start <- batch.win.1[1]
            batch.win1.end <- batch.win.1[2]
            batch.win2.start <- batch.win.2[1]
            batch.win2.end <- batch.win.2[2]
            
            bd <- binData(data = batchDataIn()[[i]], input.bin = input$batch.in.bin, output.bin = input$batch.out.bin, t.cycle = input$batch.t.cycle)
            batch.com.data <- CoM(input = bd, data = "Activity", bin = input$batch.out.bin,
                                  t.cycle = input$batch.t.cycle, window = list(c(batch.win1.start, batch.win1.end), c(batch.win2.start, batch.win2.end)))
            
            tmp.out[[i]] <- batch.com.data$Data
            
          } else if (input$batch.circstat.act.slp == "Sleep") {
            
            batch.for.def.sleep.input <- strsplit(input$batch.def.sleep.circ, split = "-")
            batch.pre.def.sleep.input <- unlist(lapply(batch.for.def.sleep.input, FUN = as.numeric))
            
            if (length(batch.pre.def.sleep.input) == 1) {
              batch.def.sleep.input = c(batch.pre.def.sleep.input[1])
            } else if (length(batch.pre.def.sleep.input) == 2) {
              batch.def.sleep.input = c(batch.pre.def.sleep.input[1], batch.pre.def.sleep.input[2])
            }
            
            sd <- sleepData(data = batchDataIn()[[i]], sleep.def = batch.def.sleep.input, bin = input$batch.out.bin, t.cycle = input$batch.t.cycle)
            
            batch.win.1 = as.numeric(unlist(strsplit(input$batch.win1, split = ",")))
            batch.win.2 = as.numeric(unlist(strsplit(input$batch.win2, split = ",")))
            
            batch.win1.start <- batch.win.1[1]
            batch.win1.end <- batch.win.1[2]
            batch.win2.start <- batch.win.2[1]
            batch.win2.end <- batch.win.2[2]
            
            batch.com.data <- CoM(input = sd, data = "Sleep", bin = input$batch.out.bin,
                                  t.cycle = input$batch.t.cycle, window = list(c(batch.win1.start, batch.win1.end), c(batch.win2.start, batch.win2.end)))
            
            tmp.out[[i]] <- batch.com.data$Data
            
          }
          
        }
        incProgress(1/length(batchDataIn()), detail = paste("Completed", i))
        Sys.sleep(0.1)
      }
      
    })
    
    return(tmp.out)
  })
  
  compiledDat <- reactive({
    new.df <- list()
    for (i in 1:length(batch.out.data())) {
      pre.new.df <- cbind(
        rep(batchNames()[i], length(batch.out.data()[[i]][,1])),
        batch.out.data()[[i]]
      )
      colnames(pre.new.df)[1] <- c("MonitorDetails")
      new.df[[i]] <- pre.new.df
    }
    
    out.df <- do.call(cbind, new.df)
    return(out.df)
  })
  
  
  output$batch.download.preview <- renderTable({
    head(compiledDat())
  })
  
  output$batch.download.dat <- downloadHandler(
    filename = function() {
      paste(final.batch.names())
    },
    content = function(file) {
      write.csv(compiledDat(), file, row.names = F)
    }
  )
  
})