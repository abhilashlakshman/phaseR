library(shiny)
library(shinythemes)
library(shinydashboard)
library(plotly)
library(shinycssloaders)
library(shinyFiles)
library(phase)
library(plotly)
library(zoo)


# potentially good themes: cosmo, readable, spacelab, journal, slate, sandstone, darkly
shinyUI <- navbarPage("phaseR", theme = shinytheme("readable"),
                      
                      tabPanel("Input",
                               fluidPage(
                                 
                                 sidebarLayout(
                                   
                                   sidebarPanel(
                                     
                                     width = 3,
                                     
                                     shinythemes::themeSelector(),
                                     
                                     fileInput("file", "Choose DAM Monitor File",
                                               multiple = FALSE,
                                               accept = c("text/csv",
                                                          "text/comma-separated-values,text/plain",
                                                          ".csv")),
                                     
                                     textInput(inputId = "dat.tim",
                                               label = "Analysis start date and time (DD Mon YY; HH:MM); Always use ZT00/CT00 as start time to ensure that all analyses work as expected",
                                               value = format(Sys.time(), "%d %b %y; %H:%M")),
                                     
                                     numericInput(inputId = "cyc",
                                                  label = "Number of days to analyse",
                                                  value = 5, min = 1, max = 30, step = 1),
                                     
                                     sliderInput("in.bin", "Input bin (min)",
                                                 min = 1, max = 720, value = 1, step = 1),
                                     
                                     sliderInput("out.bin", "Output bin (min)",
                                                 min = 1, max = 720, value = 30, step = 1),
                                     
                                     numericInput(
                                       inputId = "t.cycle",
                                       label = "T-cycle/Modulo tau",
                                       value = 24, min = 10, max = 32, step = 0.5),
                                     
                                     selectInput("analysis", "Data to analyse:",
                                                 choices = c("Activity", "Sleep" #, "Wakefulness"
                                                 )),
                                     
                                     textInput(
                                       inputId = "def.sleep",
                                       label = "Sleep Definition (mins); Input here is only required if your above choice was Sleep or Wakefulness (can also be a range of values; e.g. 5-10 will analyse sleep that only has bout lengths between 5 and 10 minutes)",
                                       value = 5),
                                     
                                     textInput(
                                       inputId = "act.color",
                                       label = "Color of actograms/somnograms. Enter values in the following format: r,g,b,t - r, g and b are red, green and blue values that range from 0-1. t is the transparency value which also ranged from 0-1. Therefore, 0,0,0,1 would mean black with full opacity; 0,0,0,0.5 would be black with 50% transparency and so on.",
                                       value = "0,0,0,1"),
                                     
                                     tags$hr(style = "border-top: 1px solid #000000;"),
                                     
                                     actionButton("preview.dat.button", "Preview data")
                                     
                                   ),
                                   
                                   mainPanel(
                                     tabsetPanel(
                                       
                                       tabPanel("Trimmed data",
                                                h4("NOTE: This table only shows the first 10 rows of data. This is meant to make sure that your start date and time are correct and that the file can be read."),
                                                box(
                                                  height = 12,
                                                  div(style = "overflow-x: scroll", tableOutput("preview.dat"))
                                                )
                                       ),
                                       
                                       tabPanel("Binned data",
                                                box(
                                                  width = 12,
                                                  div(style = "overflow-x: scroll", tableOutput("preview.binned.dat"))
                                                )
                                       )
                                       
                                     )
                                     
                                   )
                                   
                                 )
                               )
                               
                      ),
                      
                      tabPanel("Full monitor data",
                               mainPanel(
                                 withSpinner(plotlyOutput("full.mon.dat", width = "1300px", height = "1000px"))
                               )
                      ),
                      
                      tabPanel("All periodograms",
                               fluidPage(
                                 
                                 sidebarLayout(
                                   
                                   sidebarPanel(
                                     
                                     width = 3,
                                     
                                     selectInput("per.method", "Periodogram Method",
                                                 choices = c("ChiSquare",
                                                             "Autocorrelation",
                                                             "LombScargle")
                                     ),
                                     
                                     numericInput(inputId = "low.per", label = "Lowest period (hrs)",
                                                  value = 14, min = 6, max = 22, step = 1
                                                  
                                     ),
                                     
                                     numericInput(inputId = "high.per", label = "Highest period (hrs)",
                                                  value = 32, min = 26, max = 36, step = 1
                                                  
                                     ),
                                     
                                     numericInput(inputId = "alpha.per", label = "Alpha for significance tests",
                                                  value = 0.05, min = 0.01, max = 0.1, step = 0.01
                                                  
                                     ),
                                     
                                     sliderInput(inputId = "res.per", label = "Resolution of periods to analyse (mins)",
                                                 min = 10, max = 360, value = 20, step = 5
                                                 
                                     ),
                                     
                                     tags$hr(style = "border-top: 1px solid #000000;"),
                                     
                                     actionButton("period.dat.table.figure", "Generate plots and data")
                                     
                                   ),
                                   
                                   mainPanel(
                                     tabsetPanel(
                                       
                                       tabPanel("Plots",
                                                box(
                                                  width = 12,
                                                  # height = 6,
                                                  withSpinner(plotlyOutput("all.periodogram.plot"))
                                                  # div(style = "overflow-x: scroll", tableOutput("preview.dat"))
                                                )
                                       ),
                                       
                                       tabPanel("Data",
                                                box(
                                                  # height = 350,
                                                  div(style = "overflow-x: scroll; overflow-y: scroll", tableOutput("all.periodogram.dat")),
                                                  downloadButton(outputId = "all.period.power.download", label = "Download data")
                                                )
                                       )
                                       
                                     )
                                   )
                                 )
                                 
                               )
                      ),
                      
                      tabPanel("Individual data",
                               sidebarLayout(
                                 sidebarPanel(
                                   numericInput(inputId = "channel", "Channel number:",
                                                value = 1, min = 1, max = 32, step = 1
                                   ),
                                   
                                   tags$hr(style = "border-top: 1px solid #000000;"),
                                   
                                   # actionButton("for.ind.data", "Generate plots"),
                                   
                                   width = 2
                                 ),
                                 
                                 mainPanel(
                                   width = 10,
                                   box(
                                     title = "Acto/Somno-gram",
                                     # height = "300px",
                                     width = 5,
                                     # height = 10,
                                     solidHeader = T,
                                     withSpinner(plotlyOutput("ind.actogram"))
                                   ),
                                   
                                   box(
                                     title = "Chi-Sq",
                                     # height = "300px",
                                     width = 5,
                                     # height = 10,
                                     solidHeader = T,
                                     withSpinner(plotlyOutput("ind.periodogram.cs"))
                                   ),
                                   
                                   box(
                                     title = "LS",
                                     # height = "300px",
                                     width = 5,
                                     # height = 10,
                                     solidHeader = T,
                                     withSpinner(plotlyOutput("ind.periodogram.ls"))
                                   ),
                                   
                                   box(
                                     title = "Autocorr",
                                     # height = "300px",
                                     width = 5,
                                     # height = 10,
                                     solidHeader = T,
                                     withSpinner(plotlyOutput("ind.periodogram.auto"))
                                   ),
                                   
                                   box(
                                     width = 10,
                                     div(style = "overflow-x: scroll", tableOutput("dataTable.phase")),
                                     downloadButton(outputId = "phase.download", label = "Download data")
                                   )
                                   
                                 )
                                 
                               )
                      ),
                      
                      tabPanel("Continuous Wavelet Transforms",
                               sidebarLayout(
                                 sidebarPanel(
                                   numericInput(inputId = "low.per.cwt", label = "Lowest period (hrs)",
                                                value = 1, min = 1, max = 100, step = 1
                                                
                                   ),
                                   
                                   numericInput(inputId = "high.per.cwt", label = "Highest period (hrs)",
                                                value = 35, min = 1, max = 100, step = 1
                                                
                                   ),
                                   
                                   
                                   textInput("rm.chan.cwt", "Channels to remove", value = "None"),
                                   helpText("Separate channels by a comma (e.g. 1,3,5,14); Continuous channels can be separated using a colon (e.g. 1:10 - will remove channels 1 through 10); If users want to remove channels 1,3,5, 17 through 20, and 31 and 32, the input can be 1,3,5,17:20,31:32. If no channels must be removed, then the input should be None."),
                                   
                                   selectInput("edge.rm.cwt", "Remove Edge Effects in Scalogram:",
                                               choices = c(TRUE, FALSE
                                               )),
                                   
                                   
                                   # selectInput("pval.cwt", "Generate p-values:",
                                   #             choices = c(FALSE, TRUE
                                   #             )),
                                   # 
                                   # selectInput("pval.method.cwt", "Method to generate p-values:",
                                   #             choices = c("Shuffle", "White Noise", "Fourier Randomization"
                                   #             )),
                                   
                                   # numericInput(inputId = "n.sim.cwt", "Number of simulations for generating p-values:",
                                   #              value = 1000, min = 100, max = 10000, step = 1
                                   # ),
                                   
                                   numericInput(inputId = "z.max.cwt", "Maximum color value for scalograms:",
                                                value = 1, min = 0, max = 10, step = 0.05
                                   ),
                                   
                                   numericInput(inputId = "y.max.cwt", "Maximum value on the y-axis for period vs power plots",
                                                value = 5, min = 0, max = 10, step = 0.05
                                   ),
                                   
                                   selectInput("boot.cwt.logical", "Bootstrap 95% confidence intervals",
                                               choices = c(TRUE, FALSE
                                               )),
                                   
                                   numericInput(inputId = "boot.rep", "Replicates for bootstrapping",
                                                value = 1000, min = 0, max = 100000, step = 1
                                   ),
                                   
                                   numericInput(inputId = "channel.cwt", "Replicate number:",
                                                value = 1, min = 1, max = 32, step = 1
                                   ),
                                   
                                   tags$hr(style = "border-top: 1px solid #000000;"),
                                   
                                   numericInput(inputId = "low.per.ultradian", label = "Lower limit for ultradian period (hrs)",
                                                value = 1, min = 1, max = 19, step = 1
                                                
                                   ),
                                   
                                   numericInput(inputId = "high.per.ultradian", label = "Upper limit for ultradian period (hrs)",
                                                value = 4, min = 2, max = 20, step = 1
                                                
                                   ),
                                   
                                   tags$hr(style = "border-top: 1px solid #000000;"),
                                   
                                   actionButton("compute.scalogram", "Analyze and Plot"),
                                   
                                   width = 2
                                 ),
                                 
                                 mainPanel(
                                   tabsetPanel(
                                     
                                     tabPanel("Scalograms",
                                              box(
                                                width = 12,
                                                withSpinner(plotlyOutput("mean.scalogram", height = '600px')),
                                                downloadButton(outputId = "scalogram.dat.download", label = "Download data")
                                              )
                                     ),
                                     
                                     tabPanel("Period vs Power Plots",
                                              box(
                                                width = 12,
                                                height = 12,
                                                withSpinner(plotOutput("cwt.period.power"))
                                              )
                                     ),
                                     
                                     tabPanel("Period vs Power Data",
                                              box(
                                                div(style = "overflow-x: scroll; overflow-y: scroll", tableOutput("cwt.period.power.dat")),
                                                downloadButton(outputId = "cwt.period.power.download", label = "Download data")
                                              )
                                     ),
                                     
                                     tabPanel("Individual Scalograms",
                                              withSpinner(plotlyOutput("ind.scalogram", width = "1300px", height = "1000px"))
                                     ),
                                     
                                     tabPanel("Extract ultradian periodicity",
                                              h4("NOTE: This will extract the mean period in a defined range for each fly."),
                                              box(
                                                div(style = "overflow-x: scroll; overflow-y: scroll", tableOutput("cwt.ultradian.period.dat")),
                                                downloadButton(outputId = "cwt.ultradian.period.download", label = "Download data")
                                              )
                                     )
                                     
                                   )
                                 )
                                 
                               )
                      ),
                      
                      tabPanel("Profiles",
                               sidebarLayout(
                                 sidebarPanel(
                                   selectInput("avg.type", "Average over",
                                               choices = c("Flies", "Days", "Both", "None")),
                                   textInput("rm.chan.prof", "Channels to remove", value = "None"),
                                   helpText("Separate channels by a comma (e.g. 1,3,5,14); Continuous channels can be separated using a colon (e.g. 1:10 - will remove channels 1 through 10); If users want to remove channels 1,3,5, 17 through 20, and 31 and 32, the input can be 1,3,5,17:20,31:32. If no channels must be removed, then the input should be None."),
                                   width = 2
                                 ),
                                 
                                 mainPanel(
                                   tabsetPanel(
                                     
                                     tabPanel("Plots",
                                              box(
                                                width = 12,
                                                withSpinner(plotlyOutput("profile.plot"))
                                              )
                                     ),
                                     
                                     tabPanel("Data",
                                              box(
                                                div(style = "overflow-x: scroll; overflow-y: scroll", tableOutput("profile.dat")),
                                                downloadButton(outputId = "profile.download", label = "Download data")
                                              )
                                     )
                                     
                                   )
                                 )
                               )
                      ),
                      
                      tabPanel("Sleep statistics",
                               sidebarLayout(
                                 sidebarPanel(
                                   textInput("rm.chan.slp.stat", "Channels to remove", value = "None"),
                                   helpText("Separate channels by a comma (e.g. 1,3,5,14); Continuous channels can be separated using a colon (e.g. 1:10 - will remove channels 1 through 10); If users want to remove channels 1,3,5, 17 through 20, and 31 and 32, the input can be 1,3,5,17:20,31:32. If no channels must be removed, then the input should be None."),
                                   tags$hr(style = "border-top: 1px solid #000000;"),
                                   numericInput(inputId = "viz.photoperiod", label = "Length of photoperiod (h)", value = 12),
                                   numericInput(inputId = "ch.viz", label = "Channel to visualize", value = 1, min = 1, max = 32, step = 1),
                                   width = 2
                                 ),
                                 mainPanel(
                                   tabsetPanel(
                                     
                                     tabPanel("Bout distribution",
                                              h4("NOTE: This plots the freqeuncy distribution of sleep bout lengths for each fly, pooled over the all the days of the user-chosen analysis window."),
                                              box(
                                                width = 12,
                                                withSpinner(plotlyOutput("bout.dist", height = '600px'))
                                              )
                                     ),
                                     
                                     tabPanel("Bout distribution data",
                                              box(
                                                div(style = "overflow-x: scroll; overflow-y: scroll", tableOutput("bout.dist.dat1")),
                                                downloadButton(outputId = "bout.dist.download1", label = "Download data")
                                              )
                                     ),
                                     
                                     tabPanel("Hypnograms",
                                              h4("NOTE: This plots hypnograms that help to visualize sleep in different sleep stages. For examining the amounts of sleep in these windows, please download profiles using different definitions of sleep. The short sleep category is defined as any bout of inactivity that is 5 to 30-mins long (light blue), the intermediate sleep is defined as any bout of inactivity that is 30 to 60-mins (medium blue) and deep sleep is defined as any bout of inactivity that is equal to or longer than 60-mins (dark blue). Activity is shown in red. At the moment this visualization is only accurate for 24-h days."),
                                              box(
                                                width = 12,
                                                height = 12,
                                                withSpinner(plotOutput("hypnograms"))
                                              )
                                     ),
                                     
                                     tabPanel("Sleep statistics plots",
                                              box(
                                                width = 12,
                                                withSpinner(plotlyOutput("slp.stat.plot1", height = '600px'))
                                              )
                                     ),
                                     
                                     tabPanel("Sleep statistics data",
                                              box(
                                                div(style = "overflow-x: scroll; overflow-y: scroll", tableOutput("slp.stat.dat1")),
                                                downloadButton(outputId = "slp.stat.download1", label = "Download data")
                                              )
                                     )
                                     
                                   )
                                 )
                               )
                      ),
                      
                      tabPanel("Anticipation (activity)",
                               sidebarLayout(
                                 sidebarPanel(
                                   textInput("rm.chan.ant", "Channels to remove", value = "None"),
                                   helpText("Separate channels by a comma (e.g. 1,3,5,14); Continuous channels can be separated using a colon (e.g. 1:10 - will remove channels 1 through 10); If users want to remove channels 1,3,5, 17 through 20, and 31 and 32, the input can be 1,3,5,17:20,31:32. If no channels must be removed, then the input should be None."),
                                   tags$hr(style = "border-top: 1px solid #000000;"),
                                   selectInput("ant.method", "Method for anticipation analysis",
                                               choices = c("Slope", "Harrisingh")),
                                   numericInput(inputId = "morn.win.start", label = "Start of morning window (ZT); End of morning window is always taken as ZT00", value = 18),
                                   numericInput(inputId = "eve.win.start", label = "Start of evening window (ZT)", value = 6),
                                   numericInput(inputId = "eve.win.end", label = "End of evening window (ZT)", value = 12),
                                   textInput("max.y.ant", "Max value of y-axis (in anticipation plots)", value = "Automatic"),
                                   
                                   width = 2
                                 ),
                                 mainPanel(
                                   tabsetPanel(
                                     
                                     tabPanel("Plots",
                                              box(
                                                width = 12,
                                                withSpinner(plotlyOutput("ant.lat.plot"))
                                              )
                                     ),
                                     
                                     tabPanel("Data",
                                              box(
                                                div(style = "overflow-x: scroll; overflow-y: scroll", tableOutput("ant.lat.dat")),
                                                downloadButton(outputId = "ant.lat.download", label = "Download data")
                                              )
                                     )
                                     
                                   )
                                 )
                               )
                      ),
                      
                      tabPanel("Phases of peaks",
                               sidebarLayout(
                                 sidebarPanel(
                                   
                                   numericInput(inputId = "filt.order", "Filter Order:",
                                                value = 3, min = 1, max = 20, step = 1),
                                   helpText("Filter order is the order of the polynomial used"),
                                   tags$hr(style = "border-top: 1px solid #000000;"),
                                   numericInput(inputId = "filt.length", "Filter Length:",
                                                value = 51, min = 11, max = 201, step = 2),
                                   helpText("This is the length of the filter applied on the raw data. Must be an odd number. The input here is in time indices. Data is smoothed using 5-min binned activity data. An input of 51 means 51 5-min windows which is 255-mins or 4.25-h."),
                                   tags$hr(style = "border-top: 1px solid #000000;"),
                                   numericInput(inputId = "min.peak.dist", "Minimum distance between peaks:",
                                                value = 100, min = 1, max = 500, step = 1),
                                   helpText("This is the minimum distance between two peaks to be indentified as a peak. The input here is also in time indices, as described above."),
                                   tags$hr(style = "border-top: 1px solid #000000;"),
                                   numericInput(inputId = "peak.ht.scal", "Peak height scaling factor:",
                                                value = 0.5, min = 0, max = 1, step = 0.1),
                                   helpText("This is the relative height of a second peak to be considered a peak"),
                                   tags$hr(style = "border-top: 1px solid #000000;"),
                                   textInput("pk.win1", "Expected time of morning peak (ZT)", value = "0"),
                                   textInput("pk.win2", "Expected time of evening peak (ZT)", value = "12"),
                                   # textInput("pk.rm.chan", "Channels to remove", value = "None"),
                                   
                                   actionButton("for.pk.id", "Generate plots and data"),
                                   
                                   width = 2
                                 ),
                                 mainPanel(
                                   tabsetPanel(
                                     
                                     tabPanel("Plots",
                                              h3("NOTE: Peaks are identified closest to the provided ZT values."),
                                              box(
                                                width = 12,
                                                withSpinner(plotlyOutput("pk.identifier.plot"))
                                              )
                                     ),
                                     
                                     tabPanel("Data",
                                              box(
                                                h3("NOTE: Peaks are identified closest to the provided ZT values."),
                                                div(style = "overflow-x: scroll; overflow-y: scroll", tableOutput("pk.id.dat")),
                                                downloadButton(outputId = "pk.id.download", label = "Download data")
                                              )
                                     )
                                     
                                   )
                                 )
                               )
                      ),
                      
                      tabPanel("Rose plots and CoM",
                               sidebarLayout(
                                 sidebarPanel(
                                   textInput("rm.chan.circ", "Channels to remove", value = "None"),
                                   helpText("Separate channels by a comma (e.g. 1,3,5,14); Continuous channels can be separated using a colon (e.g. 1:10 - will remove channels 1 through 10); If users want to remove channels 1,3,5, 17 through 20, and 31 and 32, the input can be 1,3,5,17:20,31:32. If no channels must be removed, then the input should be None."),
                                   textInput("win1", "Start and end times of morning window (ZT)", value = "21,3"),
                                   textInput("win2", "Start and end times of evening window (ZT)", value = "9,15"),
                                   
                                   width = 2
                                 ),
                                 mainPanel(
                                   tabsetPanel(
                                     
                                     tabPanel("Plots",
                                              box(
                                                width = 6,
                                                withSpinner(plotlyOutput("rose.plot"))
                                              ),
                                              box(
                                                width = 6,
                                                withSpinner(plotlyOutput("com.plot"))
                                              )
                                     ),
                                     
                                     tabPanel("Data",
                                              box(
                                                div(style = "overflow-x: scroll; overflow-y: scroll", tableOutput("com.dat")),
                                                downloadButton(outputId = "com.download", label = "Download data")
                                              )
                                     )
                                     
                                   )
                                 )
                               )
                      ),
                      ##########################################################
                      ##########################################################
                      ##########################################################
                      tabPanel("Batch process",
                               fluidPage(
                                 
                                 sidebarLayout(
                                   
                                   sidebarPanel(
                                     
                                     width = 3,
                                     
                                     fileInput("batch.file", "Choose scanned monitor files for batch analyses",
                                               multiple = TRUE,
                                               accept = c("text/csv",
                                                          "text/comma-separated-values,text/plain",
                                                          ".csv")),
                                     
                                     textInput(inputId = "batch.dat.tim", label = "Analysis start date and time (DD Mon YY; HH:MM); Always use ZT00/CT00 as start time to ensure that all analyses work as expected",
                                               value = format(Sys.time(), "%d %b %y; %H:%M")),
                                     
                                     numericInput(inputId = "batch.cyc",
                                                  label = "Number of days to analyse",
                                                  value = 5, min = 1, max = 30, step = 1),
                                     
                                     sliderInput("batch.in.bin", "Input bin (min)",
                                                 min = 1, max = 720, value = 1, step = 1),
                                     
                                     sliderInput("batch.out.bin", "Output bin (min)",
                                                 min = 1, max = 720, value = 30, step = 1),
                                     
                                     numericInput(
                                       inputId = "batch.t.cycle",
                                       label = "T-cycle/Modulo tau",
                                       value = 24, min = 10, max = 32, step = 0.5),
                                     
                                     
                                     selectInput("batch.analysis", "Batch data to analyse and download:",
                                                 choices = c("Period and power",
                                                             "Profiles",
                                                             "Anticipation",
                                                             "Phases of activity peaks",
                                                             "Sleep statistics",
                                                             "Circular statistics")
                                     ),
                                     
                                     conditionalPanel(
                                       condition = "input['batch.analysis'] == 'Period and power'",
                                       
                                       selectInput("batch.per.method", "Periodogram Method",
                                                   choices = c("ChiSquare",
                                                               "Autocorrelation",
                                                               "LombScargle")
                                       ),
                                       
                                       numericInput(inputId = "batch.low.per", label = "Lowest period (hrs)",
                                                    value = 14, min = 6, max = 22, step = 1
                                                    
                                       ),
                                       
                                       numericInput(inputId = "batch.high.per", label = "Highest period (hrs)",
                                                    value = 32, min = 26, max = 36, step = 1
                                                    
                                       ),
                                       
                                       numericInput(inputId = "batch.alpha.per", label = "Alpha for significance tests",
                                                    value = 0.05, min = 0.01, max = 0.1, step = 0.01
                                                    
                                       ),
                                       
                                       sliderInput(inputId = "batch.res.per", label = "Resolution of periods to analyse (mins)",
                                                   min = 10, max = 360, value = 20, step = 5
                                       ),
                                       
                                       selectInput("batch.perpow.act.slp", "Data to download:",
                                                   choices = c("Activity",
                                                               "Sleep")),
                                       
                                       conditionalPanel(
                                         condition = "input['batch.perpow.act.slp'] == 'Sleep'",
                                         
                                         textInput(
                                           inputId = "batch.def.sleep.perpow",
                                           label = "Sleep Definition (mins); Can also be a range of values - e.g. 5-10 will analyse sleep that only has bout lengths between 5 and 10 minutes.",
                                           value = 5)
                                       )
                                     ),
                                     
                                     
                                     conditionalPanel(
                                       condition = "input['batch.analysis'] == 'Profiles'",
                                       
                                       selectInput("batch.avg.type", "Average over",
                                                   choices = c("Flies", "Days", "Both", "None")),
                                       
                                       selectInput("batch.pro.act.slp", "Data to download:",
                                                   choices = c("Activity",
                                                               "Sleep")
                                                   ),
                                       
                                       conditionalPanel(
                                         condition = "input['batch.pro.act.slp'] == 'Sleep'",
                                         
                                         textInput(
                                           inputId = "batch.def.sleep.pro",
                                           label = "Sleep Definition (mins); Can also be a range of values - e.g. 5-10 will analyse sleep that only has bout lengths between 5 and 10 minutes.",
                                           value = 5)
                                       )
                                     ),
                                     
                                     conditionalPanel(
                                       condition = "input['batch.analysis'] == 'Anticipation'",
                                       
                                       selectInput("batch.ant.method", "Method for anticipation analysis",
                                                   choices = c("Slope", "Harrisingh", "Stoleru")),
                                       numericInput(inputId = "batch.morn.win.start", label = "Start of morning window (ZT); End of morning window is always taken as ZT00", value = 18),
                                       numericInput(inputId = "batch.eve.win.start", label = "Start of evening window (ZT)", value = 6),
                                       numericInput(inputId = "batch.eve.win.end", label = "End of evening window (ZT)", value = 12)
                                       
                                     ),
                                     
                                     conditionalPanel(
                                       condition = "input['batch.analysis'] == 'Phases of activity peaks'",
                                       
                                       numericInput(inputId = "batch.filt.order", "Filter Order:",
                                                    value = 3, min = 1, max = 20, step = 1),
                                       helpText("Filter order is the order of the polynomial used"),
                                       tags$hr(style = "border-top: 1px solid #000000;"),
                                       
                                       numericInput(inputId = "batch.filt.length", "Filter Length:",
                                                    value = 51, min = 11, max = 201, step = 2),
                                       helpText("This is the length of the filter applied on the raw data. Must be an odd number. The input here is in time indices. Data is smoothed using 5-min binned activity data. An input of 51 means 51 5-min windows which is 255-mins or 4.25-h."),
                                       tags$hr(style = "border-top: 1px solid #000000;"),
                                       
                                       numericInput(inputId = "batch.min.peak.dist", "Minimum distance between peaks:",
                                                    value = 100, min = 1, max = 500, step = 1),
                                       helpText("This is the minimum distance between two peaks to be indentified as a peak. The input here is also in time indices, as described above."),
                                       tags$hr(style = "border-top: 1px solid #000000;"),
                                       
                                       numericInput(inputId = "batch.peak.ht.scal", "Peak height scaling factor:",
                                                    value = 0.5, min = 0, max = 1, step = 0.1),
                                       helpText("This is the relative height of a second peak to be considered a peak"),
                                       tags$hr(style = "border-top: 1px solid #000000;"),
                                       
                                       textInput("batch.pk.win1", "Expected time of morning peak (ZT)", value = "0"),
                                       
                                       textInput("batch.pk.win2", "Expected time of evening peak (ZT)", value = "12")
                                       
                                     ),
                                     
                                     conditionalPanel(
                                       condition = "input['batch.analysis'] == 'Sleep statistics'",
                                       
                                       numericInput(inputId = "batch.photoperiod", label = "Length of photoperiod (h)", value = 12),
                                       
                                       textInput(
                                         inputId = "batch.def.sleep.stat",
                                         label = "Sleep Definition (mins); Can also be a range of values - e.g. 5-10 will analyse sleep that only has bout lengths between 5 and 10 minutes.",
                                         value = 5)
                                     ),
                                     
                                     conditionalPanel(
                                       condition = "input['batch.analysis'] == 'Circular statistics'",
                                       
                                       textInput("batch.win1", "Start and end times of morning window (ZT)", value = "21,3"),
                                       textInput("batch.win2", "Start and end times of evening window (ZT)", value = "9,15"),
                                       
                                       selectInput("batch.circstat.act.slp", "Data to download:",
                                                   choices = c("Activity",
                                                               "Sleep")),
                                       
                                       conditionalPanel(
                                         condition = "input['batch.circstat.act.slp'] == 'Sleep'",
                                         
                                         textInput(
                                           inputId = "batch.def.sleep.circ",
                                           label = "Sleep Definition (mins); Can also be a range of values - e.g. 5-10 will analyse sleep that only has bout lengths between 5 and 10 minutes.",
                                           value = 5)
                                       )
                                     )
                                   ),
                                   
                                   mainPanel(
                                     tabsetPanel(
                                       
                                       tabPanel("Preview details",
                                                box(
                                                  width = 12,
                                                  div(style = "overflow-x: scroll", tableOutput("batch.preview.dat"))
                                                )
                                       ),
                                       
                                       tabPanel("Output File Names and Download Data",
                                                box(
                                                  width = 12,
                                                  div(style = "overflow-x: scroll", tableOutput("batch.download.preview")),
                                                  downloadButton(outputId = "batch.download.dat", label = "Download data")
                                                )
                                       )
                                       
                                     )
                                     
                                   )
                                   
                                 )
                               )
                               
                      )
                      ##########################################################
                      ##########################################################
                      ##########################################################
)
